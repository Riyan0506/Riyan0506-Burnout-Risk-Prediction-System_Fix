# Email & Google Calendar Integration Setup Guide

Panduan lengkap untuk setup email notification dan Google Calendar wellness reminders.

---

## 📧 Email Setup (Gmail)

### Prerequisite
- Akun Gmail (active)
- 2-Factor Authentication enabled

### Step 1: Enable 2FA di Gmail

1. Go to: https://myaccount.google.com
2. Click **"Security"** di sidebar kiri
3. Click **"2-Step Verification"**
4. Follow instruksi (gunakan phone/authenticator app)
5. Verify dengan kode yang dikirim ke phone Anda

### Step 2: Create App Password

> **Why App Password?** App Password lebih aman daripada password Gmail biasa. Gmail tidak akan biarkan login dari aplikasi eksternal tanpa App Password jika 2FA enabled.

1. Go to: https://myaccount.google.com/apppasswords
2. Select **"Mail"** dari dropdown pertama
3. Select **"Windows Computer"** (atau device Anda) dari dropdown kedua
4. Click **"Generate"**
5. Google akan menampilkan 16-character password
6. Copy password ini (tanpa spaces)

### Step 3: Setup Environment Variables

#### Option A: Windows PowerShell (Recommended)

```powershell
# Set temporary env vars (for current session)
$env:GMAIL_ADDRESS="your-email@gmail.com"
$env:GMAIL_PASSWORD="your-16-char-app-password"

# Verify
Write-Output $env:GMAIL_ADDRESS
Write-Output $env:GMAIL_PASSWORD

# Run Streamlit
streamlit run dashboard_burnout.py
```

#### Option B: Create .env File

1. Buat file `.env` di project root:

```
GMAIL_ADDRESS=your-email@gmail.com
GMAIL_PASSWORD=your-16-char-app-password
```

2. Install python-dotenv (already in requirements.txt):

```bash
pip install python-dotenv
```

3. The code akan automatically load dari `.env`

#### Option C: Input di Streamlit Form

Di halaman "⏰ Reminder Burnout Check", input:
- **Gmail Pengirim**: your-email@gmail.com
- **App Password**: your-16-char-app-password

### Step 4: Test Email Sending

1. Open Streamlit dashboard:
```bash
streamlit run dashboard_burnout.py
```

2. Go to **"⏰ Reminder Burnout Check"** tab
3. Click **"📧 Email Report"** tab
4. Input employee data
5. Click **"📧 Kirim Laporan ke Email"**
6. Check penerima email (biasanya masuk dalam 1-2 menit)

### Troubleshooting Email

| Problem | Solution |
|---------|----------|
| "Authentication failed" | Pastikan gunakan **App Password**, bukan password Gmail |
| Email masuk ke Spam | Check spam folder, add sender to contacts |
| 16-char password tidak valid | Re-generate di https://myaccount.google.com/apppasswords |
| "Less secure apps blocked" | Disable 2FA tidak membantu. Gunakan App Password saja |

---

## 📅 Google Calendar Setup

### Prerequisite
- Google Account
- Google Calendar active

### Step 1: Create Google Cloud Project

1. Go to: https://console.cloud.google.com
2. Click **"Select a Project"** di top left
3. Click **"NEW PROJECT"**
4. Name: `Burnout Prediction System` (atau nama lain)
5. Click **"CREATE"**
6. Tunggu project di-create (1-2 menit)

### Step 2: Enable Google Calendar API

1. Di project dashboard, search bar cari: **"Google Calendar API"**
2. Click hasil search
3. Click **"ENABLE"**
4. Tunggu API di-enable

### Step 3: Create OAuth 2.0 Credentials

1. Go to **"Credentials"** di sidebar
2. Click **"+ CREATE CREDENTIALS"**
3. Select **"OAuth 2.0 Client IDs"**
4. Select **"Desktop application"** (untuk development)
5. Click **"CREATE"**
6. A popup akan tampil dengan credentials
7. Click **"DOWNLOAD"** untuk download JSON file

### Step 4: Save credentials.json

1. Download file dari Step 3
2. Rename ke: `credentials.json`
3. Move ke project root folder (tempat `dashboard_burnout.py` berada)

Structure should look like:
```
burnout_ds_project/
├── dashboard_burnout.py
├── credentials.json          ← Put it here
├── requirements.txt
├── data_dictionary.csv
├── ...
```

### Step 5: First Authentication

1. Run Streamlit:
```bash
streamlit run dashboard_burnout.py
```

2. Go to **"⏰ Reminder Burnout Check"** → **"📅 Google Calendar Wellness"** tab

3. Click **"📅 Buat Wellness Events di Google Calendar"**

4. Browser akan membuka window login Google

5. Login dengan akun Google Anda

6. Accept permissions ketika diminta

7. Login window akan close otomatis

8. Token akan di-save ke `token.json` untuk penggunaan berikutnya

### Step 6: Check Calendar

1. Open Google Calendar: https://calendar.google.com
2. Check "primary" calendar
3. Wellness events akan appear dengan warna:
   - 🔴 Red → High risk events
   - 🟡 Yellow → Medium risk events
   - 🟢 Green → Low risk events

### Troubleshooting Google Calendar

| Problem | Solution |
|---------|----------|
| "credentials.json not found" | Download & save credentials.json ke project root |
| "API not enabled" | Enable Google Calendar API di cloud console |
| "OAuth consent screen required" | Config OAuth consent screen di Credentials page |
| Events tidak muncul | Check Google Calendar, events di-create di "primary" calendar |
| "Invalid credentials" | Delete `token.json` dan authenticate ulang |
| "Access denied during first auth" | Check OAuth credentials dibuat dengan type "Desktop application" |

---

## 🔄 Complete Workflow

### Sending Email Report + Creating Calendar Events

```
User Input (Employee Data)
    ↓
Calculate Burnout Probability (Hybrid Scoring)
    ↓
├→ Send Email Report (Gmail)
│   └→ Recipient: employee@gmail.com
│   └→ Contains: Risk level, recommendations, profile
│   └→ HTML formatted dengan color coding
│
└→ Create Calendar Events (Google Calendar)
    └→ Create 12 weeks of wellness activities
    └→ Frequency: 3-6 events/week (based on risk level)
    └→ With reminders: Email (1 day before) + Popup (30 min before)
```

### Data Flow

```
Email System:
GMAIL_ADDRESS + GMAIL_PASSWORD
    ↓
SMTP (smtp.gmail.com:587)
    ↓
Recipient Email

Google Calendar System:
credentials.json (first time)
    ↓
OAuth2 Token (token.json - cached)
    ↓
Google Calendar API
    ↓
Primary Calendar
```

---

## 🔐 Security Best Practices

### ⚠️ DO:
- ✅ Use App Passwords (not Gmail password)
- ✅ Enable 2FA on Gmail
- ✅ Keep credentials.json private (add to .gitignore)
- ✅ Use environment variables for sensitive data
- ✅ Rotate app passwords periodically
- ✅ Delete token.json if re-authenticating

### ❌ DON'T:
- ❌ Never commit credentials.json to git
- ❌ Never share App Password
- ❌ Never use main Gmail password
- ❌ Never commit .env file with passwords
- ❌ Never hardcode passwords dalam code

### .gitignore Setup

```
# Add to .gitignore
credentials.json
token.json
.env
*.pkl
models/
logs/
```

---

## 📊 Email Template Preview

Karyawan akan menerima email dengan format:

```
┌─────────────────────────────────────────┐
│   🔥 Burnout Risk Assessment System     │
│   Personal Risk Evaluation Report       │
└─────────────────────────────────────────┘

Risk Level: 🟡 Sedang (65.5%)

Profile Data:
├─ Name: John Doe
├─ Age: 35 years
├─ Position: Senior Engineer
├─ Experience: 8 years
├─ Weekly Hours: 52 hours
├─ Stress Level: 7/10
└─ Satisfaction: 3.2/5

Recommendations:
• Take 30-min exercise break daily
• Practice meditation for stress relief
• Schedule 1-on-1 with manager about workload
• Improve sleep quality (target 8 hours)

[Login to Dashboard for More Details]

---
Sent from Burnout Risk Prediction System
Capstone Project Coding Camp 2026
```

---

## 📅 Calendar Event Preview

Karyawan akan see di Google Calendar:

```
Week 1, Day 1 (Sunday 09:00-09:30):
  🧘 Mindfulness & Meditation Session
  Optional Attendee: karyawan@gmail.com
  Reminders: Email 1 day before, Popup 30 min before

Week 1, Day 3 (Tuesday 12:00-12:45):
  💪 Physical Exercise & Stretching
  Optional Attendee: karyawan@gmail.com
  Reminders: Email 1 day before, Popup 30 min before

... (continues for 12 weeks)
```

---

## 🎯 Next Steps

1. ✅ Setup Gmail App Password
2. ✅ Create Google Cloud Project & enable Calendar API
3. ✅ Download credentials.json
4. ✅ Test email sending
5. ✅ Test calendar event creation
6. ✅ Verify email received
7. ✅ Verify calendar events created
8. ✅ Share dashboard dengan employees

---

## 📞 Support & FAQ

### Q: Can I use different email providers?
**A**: Current implementation is Gmail only. Can extend to support Outlook, etc.

### Q: Multiple calendars?
**A**: Current setup creates events in "primary" calendar. Can extend to custom calendars.

### Q: Bulk email sending?
**A**: Can add batch sending feature. Currently supports individual emails.

### Q: Schedule recurring emails?
**A**: Can integrate with APScheduler for scheduling. Manual for now.

### Q: What happens if Gmail/Google Calendar down?
**A**: Graceful error handling with helpful error messages. User can retry.

---

## 📝 Code Examples

### Sending Email Programmatically

```python
from email_notification import send_report_email

result = send_report_email(
    recipient_email="employee@gmail.com",
    employee_data={
        "Name": "John Doe",
        "Age": 35,
        "JobRole": "Engineer",
        # ... more data
    },
    burnout_prob=0.65,
    risk_level="Sedang",
    recommendations=[
        "Take breaks every 2 hours",
        "Practice meditation daily",
        # ... more recommendations
    ],
    sender_email="your-email@gmail.com",  # optional
    sender_password="your-app-password"    # optional
)

if result['success']:
    print("✅ Email sent!")
else:
    print(f"❌ {result['message']}")
```

### Creating Calendar Events Programmatically

```python
from google_calendar_integration import create_wellness_calendar

result = create_wellness_calendar(
    employee_email="employee@gmail.com",
    risk_level="Sedang",
    credentials_file="credentials.json"
)

if result['success']:
    print(f"✅ {result['message']}")
    for event in result['events']:
        print(f"  - {event['title']}")
else:
    print(f"❌ {result['message']}")
```

---

## 🚀 Deployment Notes

### For Cloud Deployment (Google Cloud Run, Heroku, etc.)

1. **Store credentials securely**:
   - Use Secret Manager (Google Cloud)
   - Use environment variables
   - Never commit sensitive files

2. **Handle OAuth flow**:
   - First auth might require user interaction
   - Cache token after first auth
   - Consider service account for backend-only auth

3. **Rate limiting**:
   - Gmail: ~1500 emails/day per account
   - Google Calendar: ~1000 API calls/day
   - Consider queuing for bulk operations

---

**Last Updated**: June 2, 2026  
**Version**: 1.0  
**Status**: Production Ready ✅
