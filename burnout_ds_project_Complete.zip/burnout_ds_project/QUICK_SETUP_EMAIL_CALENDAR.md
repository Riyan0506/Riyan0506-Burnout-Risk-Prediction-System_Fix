# ⚡ Quick Setup Guide - Email & Google Calendar

**TL;DR Version** - Setup dalam 5 menit

---

## 🚀 Quick Email Setup (2 menit)

### 1️⃣ Enable 2FA + Get App Password (1 min)

```
1. Go: https://myaccount.google.com/security
   → Enable 2-Step Verification

2. Go: https://myaccount.google.com/apppasswords
   → Select Mail + Windows Computer
   → Copy 16-char password
```

### 2️⃣ Set Environment Variables (1 min)

**Windows PowerShell:**
```powershell
$env:GMAIL_ADDRESS="your-email@gmail.com"
$env:GMAIL_PASSWORD="your-16-char-app-password"
```

**Or create .env file:**
```
GMAIL_ADDRESS=your-email@gmail.com
GMAIL_PASSWORD=your-16-char-app-password
```

### 3️⃣ Test Email

```bash
streamlit run dashboard_burnout.py
# Go to: ⏰ Reminder Burnout Check → 📧 Email Report
# Click: 📧 Kirim Laporan ke Email
```

---

## 📅 Quick Google Calendar Setup (3 menit)

### 1️⃣ Create Project + Enable API (1 min)

```
1. Go: https://console.cloud.google.com
2. Click: Select Project → New Project
3. Name: Burnout System → Create
4. Search: Google Calendar API → Enable
```

### 2️⃣ Get Credentials (1 min)

```
1. Go: Credentials (sidebar)
2. Click: + Create Credentials
3. Select: OAuth 2.0 Client IDs
4. App Type: Desktop application
5. Click: Create
6. Download: JSON file
```

### 3️⃣ Save credentials.json + Test

```bash
# Move downloaded file to project root:
move credentials.json "C:\path\to\burnout_ds_project\"

# Run streamlit and test
streamlit run dashboard_burnout.py
# Go to: ⏰ Reminder Burnout Check → 📅 Google Calendar Wellness
# Click: 📅 Buat Wellness Events
# Login when browser opens
```

---

## ✅ Verification Checklist

- [ ] Email setup: Env vars set (GMAIL_ADDRESS, GMAIL_PASSWORD)
- [ ] Email test: Receive test email successfully
- [ ] Calendar setup: credentials.json in project root
- [ ] Calendar test: Events created in Google Calendar
- [ ] Check email received has correct format with color coding
- [ ] Check calendar has 12 weeks of wellness events with reminders

---

## 🛑 Common Issues

| Issue | Fix |
|-------|-----|
| "Invalid credentials" | Use App Password, not Gmail password |
| "credentials.json not found" | Download & move to project root |
| Email in spam | Add sender to contacts |
| Calendar events don't show | Check "primary" calendar, refresh |
| First auth failing | Delete token.json and retry |

---

## 📚 Full Documentation

For detailed setup guide, see: [EMAIL_CALENDAR_SETUP.md](EMAIL_CALENDAR_SETUP.md)

