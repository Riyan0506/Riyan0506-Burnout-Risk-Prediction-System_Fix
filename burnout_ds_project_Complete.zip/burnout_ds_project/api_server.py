# =============================================================================
#  BURNOUT RISK PREDICTION SYSTEM — FASTAPI REST SERVER
#  Production-ready REST API for model serving
#  Capstone Project Coding Camp 2026 | CC26-PSU335
# =============================================================================

import os
import sys
from datetime import datetime
from typing import List, Optional
import numpy as np

# Add inference module to path
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
import uvicorn

# Import inference engine
from inference import BurnoutPredictor

# ──────────────────────────────────────────────────────────────────────────────
# INITIALIZATION
# ──────────────────────────────────────────────────────────────────────────────

print("="*70)
print("INITIALIZING FASTAPI SERVER")
print("="*70)

# Initialize app
app = FastAPI(
    title="🔥 Burnout Risk Prediction API",
    description="Production API for employee burnout risk assessment",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize predictor
print("\nLoading prediction model...")
try:
    predictor = BurnoutPredictor()
    print("✅ Model loaded successfully!")
except Exception as e:
    print(f"❌ Failed to load model: {e}")
    print("Make sure to run: python model_deep_learning.py")
    raise


# ──────────────────────────────────────────────────────────────────────────────
# REQUEST/RESPONSE MODELS
# ──────────────────────────────────────────────────────────────────────────────

class EmployeeData(BaseModel):
    """Employee input data for prediction"""
    Age: int = Field(..., ge=18, le=80, description="Age of employee")
    Gender: str = Field(..., description="Gender: 'Male' or 'Female'")
    JobRole: str = Field(..., description="Job role: Analyst, Engineer, HR, Manager, Sales")
    Experience: int = Field(..., ge=0, le=50, description="Years of experience")
    WorkHoursPerWeek: int = Field(..., ge=20, le=100, description="Weekly work hours")
    RemoteRatio: int = Field(..., ge=0, le=100, description="Remote work percentage")
    SatisfactionLevel: float = Field(..., ge=1.0, le=5.0, description="Job satisfaction (1-5)")
    StressLevel: int = Field(..., ge=1, le=10, description="Stress level (1-10)")
    
    class Config:
        example = {
            "Age": 35,
            "Gender": "Male",
            "JobRole": "Engineer",
            "Experience": 8,
            "WorkHoursPerWeek": 48,
            "RemoteRatio": 30,
            "SatisfactionLevel": 3.2,
            "StressLevel": 6,
        }


class PredictionResult(BaseModel):
    """Prediction output"""
    burnout_probability: float = Field(..., ge=0.0, le=1.0)
    burnout_class: int = Field(..., description="0: No Burnout, 1: Burnout")
    risk_level: str = Field(..., description="Rendah/Sedang/Tinggi")
    risk_emoji: str
    confidence: float = Field(..., ge=0.5, le=1.0)
    recommendation: str = Field(..., description="Personalized recommendation")


class HealthResponse(BaseModel):
    """Health check response"""
    status: str
    timestamp: str
    model_loaded: bool
    model_parameters: int


class BatchPredictionRequest(BaseModel):
    """Batch prediction request"""
    employees: List[EmployeeData] = Field(..., min_items=1, max_items=1000)


class BatchPredictionResult(BaseModel):
    """Batch prediction result"""
    total_employees: int
    high_risk_count: int
    medium_risk_count: int
    low_risk_count: int
    average_probability: float


# ──────────────────────────────────────────────────────────────────────────────
# HELPER FUNCTIONS
# ──────────────────────────────────────────────────────────────────────────────

def get_recommendation(probability: float, employee_data: dict) -> str:
    """
    Generate personalized recommendation based on risk level and features
    """
    risk_level = "Tinggi" if probability >= 0.7 else ("Sedang" if probability >= 0.4 else "Rendah")
    
    recommendations = {
        "Tinggi": [
            "⚠️ URGENT: Burnout risk is HIGH. Immediate intervention recommended.",
            "Consider: Reduced work hours, mental health counseling, workload redistribution.",
            "Schedule meeting with HR within 48 hours.",
            f"Current stress level: {employee_data.get('StressLevel', 0)}/10 - Focus on stress management.",
        ],
        "Sedang": [
            "⚡ Burnout risk is MEDIUM. Monitor closely and implement preventive measures.",
            "Recommendations: Improve work-life balance, consider flexible working arrangement.",
            "Schedule quarterly check-in with HR.",
            f"Satisfaction level: {employee_data.get('SatisfactionLevel', 0)}/5 - Address satisfaction concerns.",
        ],
        "Rendah": [
            "✅ Burnout risk is LOW. Continue current practices.",
            "Maintain current work-life balance and job satisfaction.",
            "Annual burnout risk assessment recommended.",
            "Consider leadership role in peer wellness programs.",
        ]
    }
    
    return " | ".join(recommendations.get(risk_level, ["No recommendation available."]))


def get_stress_signals(employee_data: dict) -> List[str]:
    """Identify risk signals from employee data"""
    signals = []
    
    if employee_data.get("StressLevel", 0) >= 7:
        signals.append("⚠️ High stress level")
    
    if employee_data.get("WorkHoursPerWeek", 0) > 50:
        signals.append("⚠️ Excessive work hours")
    
    if employee_data.get("SatisfactionLevel", 0) < 2.5:
        signals.append("⚠️ Low job satisfaction")
    
    if employee_data.get("RemoteRatio", 0) < 20:
        signals.append("⚠️ Limited remote work flexibility")
    
    if employee_data.get("Experience", 0) >= 10 and employee_data.get("StressLevel", 0) >= 6:
        signals.append("⚠️ Senior employee under stress")
    
    return signals if signals else ["✅ No major risk signals detected"]


# ──────────────────────────────────────────────────────────────────────────────
# API ENDPOINTS
# ──────────────────────────────────────────────────────────────────────────────

@app.get("/", tags=["Root"])
def read_root():
    """Root endpoint - API information"""
    return {
        "title": "🔥 Burnout Risk Prediction API",
        "version": "1.0.0",
        "documentation": "/docs",
        "endpoints": {
            "health": "/health",
            "predict": "/predict (POST)",
            "predict_batch": "/predict_batch (POST)",
        },
        "theme": "Healthy Lives & Well-being"
    }


@app.get("/health", response_model=HealthResponse, tags=["Health"])
def health_check():
    """
    Health check endpoint
    
    Returns:
        Status of API and model
    """
    try:
        model_params = predictor.model.count_params() if predictor.model else 0
        return HealthResponse(
            status="healthy",
            timestamp=datetime.now().isoformat(),
            model_loaded=predictor.model is not None,
            model_parameters=model_params,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Health check failed: {str(e)}")


@app.post("/predict", response_model=PredictionResult, tags=["Prediction"])
def predict(employee: EmployeeData):
    """
    Predict burnout risk for a single employee
    
    Args:
        employee: Employee data
    
    Returns:
        Burnout risk prediction with recommendation
    
    Example:
        {
            "Age": 35,
            "Gender": "Male",
            "JobRole": "Engineer",
            "Experience": 8,
            "WorkHoursPerWeek": 48,
            "RemoteRatio": 30,
            "SatisfactionLevel": 3.2,
            "StressLevel": 6
        }
    """
    try:
        # Convert to dict
        employee_dict = employee.dict()
        
        # Make prediction
        prediction = predictor.predict(employee_dict)
        
        # Get recommendation
        recommendation = get_recommendation(
            prediction["burnout_probability"],
            employee_dict
        )
        
        # Identify risk signals
        signals = get_stress_signals(employee_dict)
        
        return PredictionResult(
            burnout_probability=prediction["burnout_probability"],
            burnout_class=prediction["burnout_class"],
            risk_level=prediction["risk_level"],
            risk_emoji=prediction["risk_emoji"],
            confidence=prediction["confidence"],
            recommendation=recommendation,
        )
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Prediction failed: {str(e)}")


@app.post("/predict_batch", response_model=BatchPredictionResult, tags=["Prediction"])
def predict_batch(request: BatchPredictionRequest):
    """
    Predict burnout risk for multiple employees
    
    Args:
        request: Batch of employee records
    
    Returns:
        Summary of batch predictions
    """
    try:
        # Convert to list of dicts
        employees_list = [emp.dict() for emp in request.employees]
        
        # Make predictions
        results_df = predictor.predict_batch(employees_list)
        
        # Calculate statistics
        high_risk = (results_df['burnout_probability'] >= 0.7).sum()
        medium_risk = ((results_df['burnout_probability'] >= 0.4) & 
                       (results_df['burnout_probability'] < 0.7)).sum()
        low_risk = (results_df['burnout_probability'] < 0.4).sum()
        avg_prob = results_df['burnout_probability'].mean()
        
        return BatchPredictionResult(
            total_employees=len(results_df),
            high_risk_count=int(high_risk),
            medium_risk_count=int(medium_risk),
            low_risk_count=int(low_risk),
            average_probability=float(avg_prob),
        )
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Batch prediction failed: {str(e)}")


@app.post("/detailed_batch_predict", tags=["Prediction"])
def detailed_batch_predict(request: BatchPredictionRequest):
    """
    Get detailed predictions for batch of employees (returns full details)
    
    Returns:
        List of detailed predictions for each employee
    """
    try:
        # Convert to list of dicts
        employees_list = [emp.dict() for emp in request.employees]
        
        # Make predictions
        results_df = predictor.predict_batch(employees_list)
        
        # Add recommendations
        results_df['recommendation'] = results_df.apply(
            lambda row: get_recommendation(row['burnout_probability'], row),
            axis=1
        )
        
        # Convert to list of dicts
        return {
            "total": len(results_df),
            "predictions": results_df.to_dict('records')
        }
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Detailed batch prediction failed: {str(e)}")


@app.get("/model_info", tags=["Model"])
def model_info():
    """Get information about the loaded model"""
    try:
        return {
            "model_name": "BurnoutRiskPredictor",
            "model_type": "TensorFlow Functional API",
            "total_parameters": predictor.model.count_params() if predictor.model else 0,
            "input_features": predictor.features,
            "feature_count": len(predictor.features),
            "output_type": "Binary Classification",
            "output_classes": ["No Burnout", "Burnout"],
            "decision_threshold": 0.5,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Could not retrieve model info: {str(e)}")


@app.get("/risk_thresholds", tags=["Info"])
def risk_thresholds():
    """Get risk level thresholds"""
    return {
        "risk_levels": {
            "Rendah (Low)": {
                "range": "0.0 - 0.4",
                "description": "Low burnout risk",
                "action": "Monitor regularly"
            },
            "Sedang (Medium)": {
                "range": "0.4 - 0.7",
                "description": "Medium burnout risk",
                "action": "Implement preventive measures"
            },
            "Tinggi (High)": {
                "range": "0.7 - 1.0",
                "description": "High burnout risk",
                "action": "Urgent intervention required"
            }
        }
    }


# ──────────────────────────────────────────────────────────────────────────────
# ERROR HANDLERS
# ──────────────────────────────────────────────────────────────────────────────

@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    """Custom HTTP exception handler"""
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": exc.detail,
            "timestamp": datetime.now().isoformat(),
            "path": str(request.url.path),
        }
    )


# ──────────────────────────────────────────────────────────────────────────────
# STARTUP/SHUTDOWN EVENTS
# ──────────────────────────────────────────────────────────────────────────────

@app.on_event("startup")
async def startup_event():
    """Event triggered on server startup"""
    print("\n" + "="*70)
    print("✅ FastAPI Server Starting Up")
    print("="*70)
    print(f"   Timestamp: {datetime.now().isoformat()}")
    print(f"   Model loaded: {predictor.model is not None}")
    print(f"   Model parameters: {predictor.model.count_params() if predictor.model else 0:,}")
    print("\n   API Documentation:")
    print("   - Swagger UI: http://localhost:8000/docs")
    print("   - ReDoc: http://localhost:8000/redoc")
    print("\n" + "="*70)


@app.on_event("shutdown")
async def shutdown_event():
    """Event triggered on server shutdown"""
    print("\n" + "="*70)
    print("⛔ FastAPI Server Shutting Down")
    print("="*70)
    print(f"   Timestamp: {datetime.now().isoformat()}")


# ──────────────────────────────────────────────────────────────────────────────
# MAIN
# ──────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    
    print("\n" + "="*70)
    print("🔥 STARTING BURNOUT RISK PREDICTION API SERVER")
    print("="*70)
    
    # Configuration
    HOST = "0.0.0.0"
    PORT = 8000
    
    print(f"\nServer Configuration:")
    print(f"  Host: {HOST}")
    print(f"  Port: {PORT}")
    print(f"  URL: http://localhost:{PORT}")
    
    # Start server
    uvicorn.run(
        app,
        host=HOST,
        port=PORT,
        reload=False,  # Set to True for development
        log_level="info"
    )
