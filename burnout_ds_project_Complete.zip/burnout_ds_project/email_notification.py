# =============================================================================
#  EMAIL NOTIFICATION MODULE
#  Mengirim hasil prediksi burnout ke Gmail karyawan
#  Capstone Project Coding Camp 2026 | CC26-PSU335
# =============================================================================

import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
import os
from pathlib import Path

class BurnoutEmailNotifier:
    """
    Email notifier untuk mengirim hasil prediksi burnout ke Gmail
    
    Setup:
    1. Enable 2FA di akun Gmail
    2. Buat App Password: https://myaccount.google.com/apppasswords
    3. Set environment variables:
       - GMAIL_ADDRESS: email pengirim
       - GMAIL_PASSWORD: app password (bukan password Gmail biasa)
    """
    
    def __init__(self, sender_email=None, sender_password=None):
        """Initialize email notifier dengan Gmail credentials"""
        self.sender_email = sender_email or os.getenv("GMAIL_ADDRESS")
        self.sender_password = sender_password or os.getenv("GMAIL_PASSWORD")
        self.smtp_server = "smtp.gmail.com"
        self.smtp_port = 587
        
        if not self.sender_email or not self.sender_password:
            raise ValueError(
                "Email credentials tidak tersedia.\n"
                "Setup:\n"
                "1. Set GMAIL_ADDRESS env var (email pengirim)\n"
                "2. Set GMAIL_PASSWORD env var (app password, bukan password Gmail)\n"
                "3. Link: https://myaccount.google.com/apppasswords"
            )
    
    def send_burnout_report(self, recipient_email, employee_data, burnout_prob, 
                            risk_level, recommendations=None):
        """
        Kirim laporan burnout ke email karyawan
        
        Parameters:
        -----------
        recipient_email : str
            Email tujuan
        employee_data : dict
            Data karyawan (Age, Gender, JobRole, Experience, dll)
        burnout_prob : float
            Probabilitas burnout (0-1 atau 0-100)
        risk_level : str
            Level risiko (Rendah/Sedang/Tinggi)
        recommendations : list
            List rekomendasi (optional)
        
        Returns:
        --------
        dict: {success: bool, message: str}
        """
        try:
            # Normalize burnout probability
            if burnout_prob > 1:
                burnout_prob = burnout_prob / 100
            
            # Create HTML email
            html_content = self._create_html_email(
                employee_data, burnout_prob, risk_level, recommendations
            )
            
            # Create message
            message = MIMEMultipart("alternative")
            message["Subject"] = "🔥 Burnout Risk Assessment Report - Tindakan Diperlukan"
            message["From"] = self.sender_email
            message["To"] = recipient_email
            
            # Attach HTML
            message.attach(MIMEText(html_content, "html"))
            
            # Send email
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.sender_email, self.sender_password)
                server.send_message(message)
            
            return {
                "success": True,
                "message": f"✅ Email berhasil dikirim ke {recipient_email}"
            }
        
        except smtplib.SMTPAuthenticationError:
            return {
                "success": False,
                "message": "❌ Authentication gagal. Periksa email/password. Gunakan App Password, bukan password Gmail."
            }
        except smtplib.SMTPException as e:
            return {
                "success": False,
                "message": f"❌ Error mengirim email: {str(e)}"
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"❌ Error: {str(e)}"
            }
    
    def _create_html_email(self, employee_data, burnout_prob, risk_level, 
                           recommendations=None):
        """Generate HTML email content"""
        
        risk_color = {
            "Tinggi": "#ef4444",
            "Sedang": "#f59e0b",
            "Rendah": "#10b981"
        }.get(risk_level, "#666666")
        
        risk_emoji = {
            "Tinggi": "🔴",
            "Sedang": "🟡",
            "Rendah": "🟢"
        }.get(risk_level, "❓")
        
        recommendations_html = ""
        if recommendations:
            recommendations_html = """
            <h3 style="color: #333; margin-top: 20px;">📋 Rekomendasi untuk Anda:</h3>
            <ul style="line-height: 1.8; color: #555;">
            """
            for rec in recommendations[:5]:  # Max 5 rekomendasi
                recommendations_html += f"<li>{rec}</li>"
            recommendations_html += "</ul>"
        
        html = f"""
        <html>
            <head>
                <style>
                    body {{ font-family: Arial, sans-serif; background-color: #f5f5f5; }}
                    .container {{ max-width: 600px; margin: 20px auto; 
                                  background-color: white; padding: 30px; border-radius: 10px; 
                                  box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
                    .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                              color: white; padding: 20px; border-radius: 8px; text-align: center; }}
                    .risk-box {{ background-color: {risk_color}33; border-left: 5px solid {risk_color}; 
                               padding: 15px; margin: 20px 0; border-radius: 5px; }}
                    .risk-text {{ color: {risk_color}; font-size: 18px; font-weight: bold; }}
                    .data-row {{ display: flex; justify-content: space-between; 
                               padding: 10px 0; border-bottom: 1px solid #eee; }}
                    .data-label {{ font-weight: bold; color: #333; }}
                    .data-value {{ color: #666; }}
                    .action-box {{ background-color: #fff3cd; border-left: 4px solid #ffc107; 
                                 padding: 15px; margin: 20px 0; border-radius: 5px; }}
                    .action-title {{ color: #856404; font-weight: bold; }}
                    .footer {{ text-align: center; margin-top: 30px; 
                             color: #999; font-size: 12px; border-top: 1px solid #eee; 
                             padding-top: 20px; }}
                    .btn {{ display: inline-block; background-color: #667eea; color: white; 
                           padding: 10px 20px; text-decoration: none; border-radius: 5px; 
                           margin-top: 10px; }}
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>🔥 Burnout Risk Assessment System</h1>
                        <p>Hasil Evaluasi Risiko Burnout Personal Anda</p>
                    </div>
                    
                    <div style="margin: 20px 0;">
                        <p>Halo <strong>{employee_data.get('Name', 'Karyawan')}</strong>,</p>
                        <p>Berikut adalah hasil evaluasi risiko burnout Anda berdasarkan data yang diinput:</p>
                    </div>
                    
                    <div class="risk-box">
                        <p style="margin: 0;">Tingkat Risiko Burnout Anda:</p>
                        <p class="risk-text" style="margin: 10px 0; font-size: 24px;">
                            {risk_emoji} {risk_level}
                        </p>
                        <p style="margin: 0; color: #666;">
                            Probabilitas: <strong>{burnout_prob*100:.1f}%</strong>
                        </p>
                    </div>
                    
                    <h3 style="color: #333;">📊 Data Profil Anda:</h3>
                    <div class="data-row">
                        <span class="data-label">Usia:</span>
                        <span class="data-value">{employee_data.get('Age', 'N/A')} tahun</span>
                    </div>
                    <div class="data-row">
                        <span class="data-label">Posisi:</span>
                        <span class="data-value">{employee_data.get('JobRole', 'N/A')}</span>
                    </div>
                    <div class="data-row">
                        <span class="data-label">Pengalaman:</span>
                        <span class="data-value">{employee_data.get('Experience', 'N/A')} tahun</span>
                    </div>
                    <div class="data-row">
                        <span class="data-label">Jam Kerja/Minggu:</span>
                        <span class="data-value">{employee_data.get('WorkHoursPerWeek', 'N/A')} jam</span>
                    </div>
                    <div class="data-row">
                        <span class="data-label">Tingkat Stres:</span>
                        <span class="data-value">{employee_data.get('StressLevel', 'N/A')}/10</span>
                    </div>
                    <div class="data-row">
                        <span class="data-label">Kepuasan Kerja:</span>
                        <span class="data-value">{employee_data.get('SatisfactionLevel', 'N/A')}/5</span>
                    </div>
                    
                    {recommendations_html}
                    
                    <div class="action-box">
                        <p class="action-title">⚠️ Tindakan yang direkomendasikan:</p>
                        <ul style="margin: 10px 0; color: #856404;">
                            <li>Konsultasikan hasil ini dengan HR atau manager Anda</li>
                            <li>Ikuti rekomendasi wellness yang disarankan di dashboard</li>
                            <li>Lakukan self-care dan maintainance kesehatan mental</li>
                            <li>Schedule regular check-in dengan supervisor</li>
                        </ul>
                    </div>
                    
                    <p style="color: #666; line-height: 1.6;">
                        Untuk informasi lebih lanjut dan analisis mendalam, 
                        silakan akses dashboard Burnout Risk Prediction System.
                    </p>
                    
                    <div class="footer">
                        <p>Email ini dikirim otomatis dari Burnout Risk Prediction System</p>
                        <p>Capstone Project Coding Camp 2026 | CC26-PSU335</p>
                        <p>Tema: Healthy Lives & Well-being</p>
                        <p>Waktu: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
                    </div>
                </div>
            </body>
        </html>
        """
        return html


# Fungsi helper untuk mudah digunakan dari Streamlit
def send_report_email(recipient_email, employee_data, burnout_prob, risk_level, 
                      recommendations=None, sender_email=None, sender_password=None):
    """
    Helper function untuk mengirim email dari Streamlit
    
    Usage:
    ------
    result = send_report_email(
        recipient_email="employee@gmail.com",
        employee_data={...},
        burnout_prob=0.65,
        risk_level="Sedang",
        recommendations=[...],
        sender_email="your-email@gmail.com",  # optional, dari env var jika tidak disediakan
        sender_password="your-app-password"    # optional, dari env var jika tidak disediakan
    )
    
    if result['success']:
        print(result['message'])
    else:
        print(result['message'])
    """
    try:
        notifier = BurnoutEmailNotifier(sender_email, sender_password)
        return notifier.send_burnout_report(
            recipient_email, employee_data, burnout_prob, risk_level, recommendations
        )
    except Exception as e:
        return {"success": False, "message": f"Error: {str(e)}"}
