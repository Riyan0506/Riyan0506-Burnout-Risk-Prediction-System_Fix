# =============================================================================
#  BURNOUT RISK PREDICTION SYSTEM — MODEL EXPORT TO PRODUCTION FORMAT
#  Export to SavedModel and .keras formats
#  Capstone Project Coding Camp 2026 | CC26-PSU335
# =============================================================================

import os
import pickle
import json
import tensorflow as tf
from pathlib import Path
from model_deep_learning import WeightedBinaryCrossentropy

# ── Konfigurasi Path ──────────────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(BASE_DIR, "models")
EXPORTS_DIR = os.path.join(BASE_DIR, "exported_models")
os.makedirs(EXPORTS_DIR, exist_ok=True)

print("="*70)
print("EXPORTING MODELS FOR PRODUCTION")
print("="*70)


def export_to_saved_model(model, export_path):
    """
    Export TensorFlow Model to SavedModel Format
    
    SavedModel format:
    - Protobuf-based format
    - Platform-independent
    - Supports serving in TensorFlow Serving
    - Can be deployed on various platforms
    
    Directory structure:
        model_dir/
        ├── saved_model.pb
        ├── assets/
        └── variables/
            ├── variables.index
            ├── variables.data-00000-of-00001
            └── ...
    """
    print(f"\n── EXPORTING TO SAVEDMODEL FORMAT ──")
    print(f"   Target path: {export_path}")
    
    try:
        # Create directory
        os.makedirs(export_path, exist_ok=True)
        
        # Save model
        model.export(export_path)
        
        print(f"   ✅ SavedModel exported successfully!")
        print(f"\n   SavedModel structure:")
        for root, dirs, files in os.walk(export_path):
            level = root.replace(export_path, '').count(os.sep)
            indent = ' ' * 2 * level
            print(f'{indent}{os.path.basename(root)}/')
            subindent = ' ' * 2 * (level + 1)
            for file in files[:5]:  # Show first 5 files
                print(f'{subindent}{file}')
            if len(files) > 5:
                print(f'{subindent}... and {len(files)-5} more files')
        
        return True
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return False


def export_to_keras(model, export_path):
    """
    Export TensorFlow Model to Keras Format (.keras)
    
    .keras format:
    - Newer, unified format (TensorFlow 2.13+)
    - Smaller file size than SavedModel
    - Includes model architecture, weights, training config
    - Single .keras file instead of directory structure
    - Good for model distribution and versioning
    """
    print(f"\n── EXPORTING TO KERAS FORMAT (.keras) ──")
    print(f"   Target path: {export_path}")
    
    try:
        os.makedirs(os.path.dirname(export_path), exist_ok=True)
        
        # Save as .keras
        model.save(export_path)
        
        file_size_mb = os.path.getsize(export_path) / (1024 ** 2)
        print(f"   ✅ Keras format exported successfully!")
        print(f"   File size: {file_size_mb:.2f} MB")
        
        return True
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return False


def create_model_metadata(model, scaler, features, metrics, output_path):
    """
    Create metadata JSON for model deployment
    
    Includes:
    - Model architecture info
    - Input feature names and order
    - Preprocessing info
    - Performance metrics
    - Deployment instructions
    """
    print(f"\n── CREATING MODEL METADATA ──")
    print(f"   Target path: {output_path}")
    
    try:
        # Get model config
        model_config = model.get_config()
        
        metadata = {
            "model_name": "BurnoutRiskPredictor",
            "model_type": "TensorFlow Functional API",
            "version": "1.0.0",
            "task_type": "binary_classification",
            "created_date": str(pd.Timestamp.now()),
            
            "input_features": {
                "names": features,
                "count": len(features),
                "preprocessing": "StandardScaler (mean=0, std=1)"
            },
            
            "output": {
                "type": "binary_probability",
                "classes": ["No Burnout", "Burnout"],
                "threshold": 0.5
            },
            
            "performance_metrics": {
                "accuracy": float(metrics.get("Accuracy", 0)),
                "f1_score": float(metrics.get("F1", 0)),
                "precision": float(metrics.get("Precision", 0)),
                "recall": float(metrics.get("Recall", 0)),
                "auc_roc": float(metrics.get("AUC-ROC", 0)),
            },
            
            "architecture": {
                "layers": len(model.layers),
                "total_params": int(model.count_params()),
                "trainable_params": int(sum([tf.keras.backend.count_params(w) 
                                             for w in model.trainable_weights])),
            },
            
            "custom_components": {
                "loss_function": "WeightedBinaryCrossentropy",
                "callbacks": ["BestMetricCallback", "MetricsLoggingCallback"],
                "optimizer": "Adam (lr=0.001)"
            },
            
            "deployment_notes": [
                "1. Load model with: tf.keras.models.load_model(path)",
                "2. Preprocess input with StandardScaler using saved scaler",
                "3. Features must be in exact order specified in 'input_features.names'",
                "4. Output is probability of burnout (0-1)",
                "5. Apply threshold 0.5 for binary prediction"
            ]
        }
        
        with open(output_path, 'w') as f:
            json.dump(metadata, f, indent=2)
        
        print(f"   ✅ Metadata created successfully!")
        print(f"   Metadata includes:")
        print(f"   - Model architecture info")
        print(f"   - Performance metrics")
        print(f"   - Input feature specifications")
        print(f"   - Deployment instructions")
        
        return True
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return False


def load_model_for_export():
    """Load trained model and artifacts"""
    print(f"\n── LOADING TRAINED MODEL ──")
    
    try:
        # Load DL artifacts
        dl_artifacts_path = os.path.join(MODEL_DIR, "dl_artifacts.pkl")
        with open(dl_artifacts_path, "rb") as f:
            artifacts = pickle.load(f)
        
        model = artifacts["model"]
        scaler = artifacts["scaler"]
        features = artifacts["features"]
        metrics = artifacts["metrics"]
        
        print(f"   ✅ Model loaded successfully!")
        print(f"   Model layers: {len(model.layers)}")
        print(f"   Model parameters: {model.count_params():,}")
        print(f"   Features: {len(features)}")
        
        return model, scaler, features, metrics
    except Exception as e:
        print(f"   ❌ Error loading model: {e}")
        print(f"   Make sure to run: python model_deep_learning.py first")
        return None, None, None, None


def verify_exported_models(savedmodel_path, keras_path):
    """Verify exported models can be loaded"""
    print(f"\n── VERIFYING EXPORTED MODELS ──")
    
    try:
        print(f"   Loading SavedModel...")
        sm_model = saved_model = tf.saved_model.load(savedmodel_path)
        print("✅ SavedModel loaded")
        
        print(f"   Loading .keras model...")
        keras_model = tf.keras.models.load_model(keras_path)
        print(f"   ✅ .keras model loaded: {keras_model.count_params():,} parameters")
        
        return True
    except Exception as e:
        print(f"   ❌ Verification failed: {e}")
        return False


# ── Import pandas for timestamp ───────────────────────────────────────────────
import pandas as pd


# =============================================================================
# MAIN EXPORT PROCESS
# =============================================================================

if __name__ == "__main__":
    
    print("\n" + "="*70)
    print("🔥 EXPORTING BURNOUT RISK PREDICTION MODEL FOR PRODUCTION")
    print("="*70)
    
    # 1. Load model
    model, scaler, features, metrics = load_model_for_export()
    if model is None:
        print("\n❌ Failed to load model. Exiting.")
        exit(1)
    
    # 2. Export to SavedModel
    savedmodel_path = os.path.join(EXPORTS_DIR, "burnout_model_savedmodel")
    success_sm = export_to_saved_model(model, savedmodel_path)
    
    # 3. Export to .keras
    keras_path = os.path.join(EXPORTS_DIR, "burnout_model.keras")
    success_keras = export_to_keras(model, keras_path)
    
    # 4. Create metadata
    metadata_path = os.path.join(EXPORTS_DIR, "model_metadata.json")
    success_meta = create_model_metadata(model, scaler, features, metrics, metadata_path)
    
    # 5. Verify exports
    if success_sm and success_keras:
        verify_exported_models(savedmodel_path, keras_path)
    
    # 6. Summary
    print("\n" + "="*70)
    print("✅ MODEL EXPORT COMPLETED")
    print("="*70)
    
    print(f"\nExported files:")
    print(f"  📁 SavedModel: {savedmodel_path}/")
    print(f"  📄 .keras file: {keras_path}")
    print(f"  📋 Metadata: {metadata_path}")
    
    print(f"\nDeployment options:")
    print(f"  1. TensorFlow Serving: Use SavedModel format")
    print(f"  2. TensorFlow.js: Convert from SavedModel or .keras")
    print(f"  3. TensorFlow Lite: Use .keras format")
    print(f"  4. Python inference: Load with tf.keras.models.load_model()")
    
    print(f"\nUsage example (Python):")
    print(f"""
    import tensorflow as tf
    import pickle
    
    # Load model
    model = tf.keras.models.load_model('{keras_path}')
    
    # Load scaler
    with open('{os.path.join(MODEL_DIR, 'dl_artifacts.pkl')}', 'rb') as f:
        artifacts = pickle.load(f)
    scaler = artifacts['scaler']
    
    # Preprocess input
    X_new = scaler.transform(X_raw)
    
    # Make predictions
    predictions = model.predict(X_new)
    burnout_probability = predictions[:, 0]
    burnout_class = (burnout_probability > 0.5).astype(int)
    """)
