# =============================================================================
#  BURNOUT RISK PREDICTION SYSTEM — GENERATIVE AI RECOMMENDATIONS
#  AI-powered personalized wellness recommendations for burnout prevention
#  Capstone Project Coding Camp 2026 | CC26-PSU335
# =============================================================================

import os
import json
from typing import Dict, List
import warnings
warnings.filterwarnings("ignore")

# Try to import Gemini API (optional)
try:
    import google.generativeai as genai
    GEMINI_AVAILABLE = True
except ImportError:
    GEMINI_AVAILABLE = False

print("="*70)
print("GENERATIVE AI RECOMMENDATIONS MODULE")
print("="*70)
print(f"\nGemini API Available: {GEMINI_AVAILABLE}")

# ──────────────────────────────────────────────────────────────────────────────
# CONFIGURATION
# ──────────────────────────────────────────────────────────────────────────────

# Try to load API key from environment or config file
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", None)

if GEMINI_AVAILABLE and GEMINI_API_KEY:
    genai.configure(api_key=GEMINI_API_KEY)
    print(f"✅ Gemini API configured successfully")
else:
    print(f"⚠️ Gemini API not available - Using mock implementation")


# ──────────────────────────────────────────────────────────────────────────────
# MOCK RECOMMENDATIONS DATABASE
# ──────────────────────────────────────────────────────────────────────────────

RECOMMENDATIONS_DB = {
    "Tinggi": {
        "immediate_actions": [
            "🚨 Schedule immediate meeting with HR or management",
            "👨‍⚕️ Contact occupational health or mental health services",
            "📞 Reach out to employee assistance program (EAP)",
            "⏸️ Consider temporary workload reduction or leave",
        ],
        "lifestyle": [
            "😴 Aim for 7-9 hours of sleep per night",
            "🧘 Practice daily meditation or mindfulness (15-30 min)",
            "🏃 Engage in physical exercise 30 minutes daily",
            "🍎 Maintain healthy diet and nutrition",
        ],
        "workplace": [
            "📊 Discuss workload and priority adjustment with manager",
            "🚫 Set clear boundaries for work hours and emails",
            "🤝 Delegate tasks or request additional support",
            "🎯 Re-evaluate role fit and responsibilities",
        ],
        "support": [
            "👥 Join support groups for stress management",
            "📚 Take career counseling or coaching sessions",
            "🗣️ Have open conversations with trusted colleagues",
            "👨‍👩‍👧 Invest time in family and personal relationships",
        ]
    },
    "Sedang": {
        "immediate_actions": [
            "📋 Schedule check-in with HR within 1-2 weeks",
            "🎯 Create an action plan for stress reduction",
            "📱 Set reminders for wellness activities",
        ],
        "lifestyle": [
            "🧘 Try meditation apps: Headspace, Calm, Insight Timer",
            "🏃 Start a regular exercise routine (3-4x per week)",
            "🎵 Listen to relaxing music or podcasts",
            "🌳 Spend time in nature regularly",
        ],
        "workplace": [
            "💼 Optimize work schedule with flexible arrangements",
            "✅ Use task management tools (Asana, Trello, Notion)",
            "🔄 Improve time management and prioritization",
            "☕ Take regular breaks throughout the day",
        ],
        "support": [
            "💬 Talk to your manager about concerns",
            "🤝 Find a mentor or peer support partner",
            "📖 Read books on stress management and resilience",
            "💪 Build a personal support network",
        ]
    },
    "Rendah": {
        "immediate_actions": [
            "✅ Continue current wellness practices",
            "📅 Schedule regular wellness check-ins",
            "🎯 Set preventive wellness goals",
        ],
        "lifestyle": [
            "✨ Maintain consistent sleep and exercise routine",
            "🎨 Pursue hobbies and personal interests",
            "🎯 Set work-life balance goals",
            "📚 Continue learning and personal development",
        ],
        "workplace": [
            "🎖️ Share your success strategies with colleagues",
            "🤝 Mentor others in stress management",
            "💡 Propose wellness initiatives for your team",
            "🚀 Pursue career development opportunities",
        ],
        "support": [
            "🌟 Be a wellness champion for your organization",
            "📞 Help colleagues who may be struggling",
            "📝 Contribute to company wellness programs",
            "🎓 Share knowledge about burnout prevention",
        ]
    }
}


# ──────────────────────────────────────────────────────────────────────────────
# GENERATIVE AI RECOMMENDATIONS ENGINE
# ──────────────────────────────────────────────────────────────────────────────

class AIRecommendationEngine:
    """
    AI-powered recommendation system for burnout prevention
    
    Uses either Gemini API (if available) or rule-based mock implementation
    """
    
    def __init__(self, use_gemini=True):
        """Initialize the recommendation engine"""
        self.use_gemini = use_gemini and GEMINI_AVAILABLE and GEMINI_API_KEY
        self.model = None
        
        if self.use_gemini:
            try:
                self.model = genai.GenerativeModel('gemini-pro')
                print("✅ Using Gemini API for recommendations")
            except Exception as e:
                print(f"⚠️ Failed to initialize Gemini: {e}")
                print("Falling back to mock implementation")
                self.use_gemini = False
    
    def generate_recommendations(self, 
                                employee_data: Dict,
                                burnout_probability: float) -> Dict:
        """
        Generate personalized recommendations for employee
        
        Args:
            employee_data: Employee profile data
            burnout_probability: Predicted burnout probability (0-1)
        
        Returns:
            Dict with personalized recommendations
        """
        
        # Determine risk level
        if burnout_probability >= 0.7:
            risk_level = "Tinggi"
        elif burnout_probability >= 0.4:
            risk_level = "Sedang"
        else:
            risk_level = "Rendah"
        
        if self.use_gemini:
            return self._generate_gemini_recommendations(
                employee_data, burnout_probability, risk_level
            )
        else:
            return self._generate_mock_recommendations(
                employee_data, burnout_probability, risk_level
            )
    
    def _generate_gemini_recommendations(self,
                                       employee_data: Dict,
                                       burnout_probability: float,
                                       risk_level: str) -> Dict:
        """
        Generate recommendations using Gemini API
        
        Uses Gemini to create personalized, contextual recommendations
        based on employee profile and burnout risk.
        """
        
        print(f"\n📡 Calling Gemini API for personalized recommendations...")
        
        # Create context prompt
        prompt = f"""
        Based on the following employee profile and burnout assessment, 
        generate personalized, actionable wellness recommendations:
        
        EMPLOYEE PROFILE:
        - Age: {employee_data.get('Age', 'N/A')} years
        - Role: {employee_data.get('JobRole', 'N/A')}
        - Experience: {employee_data.get('Experience', 'N/A')} years
        - Work Hours: {employee_data.get('WorkHoursPerWeek', 'N/A')} hours/week
        - Remote Work: {employee_data.get('RemoteRatio', 'N/A')}%
        - Job Satisfaction: {employee_data.get('SatisfactionLevel', 'N/A')}/5
        - Stress Level: {employee_data.get('StressLevel', 'N/A')}/10
        
        BURNOUT ASSESSMENT:
        - Burnout Probability: {burnout_probability:.1%}
        - Risk Level: {risk_level}
        
        Please provide:
        1. Top 3 immediate actions
        2. Personalized wellness plan (lifestyle, work, support)
        3. Specific tools or resources recommendations
        4. Success metrics to track progress
        
        Keep recommendations practical, specific, and actionable.
        Format response as JSON with keys: immediate_actions, wellness_plan, resources, success_metrics
        """
        
        try:
            response = self.model.generate_content(prompt)
            
            # Parse response
            response_text = response.text
            
            # Try to extract JSON from response
            try:
                # Find JSON in response
                json_start = response_text.find('{')
                json_end = response_text.rfind('}') + 1
                if json_start >= 0 and json_end > json_start:
                    json_str = response_text[json_start:json_end]
                    recommendations = json.loads(json_str)
                else:
                    recommendations = {
                        "immediate_actions": [response_text],
                        "wellness_plan": ["See immediate actions above"],
                        "resources": ["Consult with HR for more resources"],
                        "success_metrics": ["Monitor stress levels weekly"]
                    }
            except json.JSONDecodeError:
                recommendations = {
                    "immediate_actions": [response_text],
                    "wellness_plan": ["Contact HR for personalized plan"],
                    "resources": ["See immediate actions"],
                    "success_metrics": ["Gradual stress reduction"]
                }
            
            return {
                "source": "Gemini AI",
                "risk_level": risk_level,
                "burnout_probability": burnout_probability,
                **recommendations
            }
        
        except Exception as e:
            print(f"⚠️ Gemini API error: {e}")
            print("Falling back to mock recommendations...")
            return self._generate_mock_recommendations(
                employee_data, burnout_probability, risk_level
            )
    
    def _generate_mock_recommendations(self,
                                      employee_data: Dict,
                                      burnout_probability: float,
                                      risk_level: str) -> Dict:
        """
        Generate recommendations using rule-based mock implementation
        
        This ensures the system works even without API access,
        using curated recommendations database.
        """
        
        recommendations = RECOMMENDATIONS_DB.get(risk_level, RECOMMENDATIONS_DB["Sedang"])
        
        # Customize based on employee profile
        customized = self._customize_recommendations(recommendations, employee_data)
        
        return {
            "source": "Rule-Based Engine",
            "risk_level": risk_level,
            "burnout_probability": float(burnout_probability),
            "immediate_actions": customized["immediate_actions"],
            "lifestyle": customized["lifestyle"],
            "workplace": customized["workplace"],
            "support": customized["support"],
        }
    
    def _customize_recommendations(self, 
                                  recommendations: Dict,
                                  employee_data: Dict) -> Dict:
        """
        Customize recommendations based on employee-specific factors
        """
        
        # Create a copy to customize
        custom = {k: v[:] for k, v in recommendations.items()}  # Shallow copy of lists
        
        # Customize based on work hours
        if employee_data.get('WorkHoursPerWeek', 40) > 50:
            custom['immediate_actions'].insert(0, "⏸️ Request workload assessment with manager")
        
        # Customize based on stress level
        if employee_data.get('StressLevel', 5) >= 8:
            custom['lifestyle'].insert(0, "🧘 Prioritize stress relief activities")
        
        # Customize based on satisfaction
        if employee_data.get('SatisfactionLevel', 3) < 2:
            custom['workplace'].insert(0, "🎯 Explore role change or development opportunities")
        
        # Customize based on remote ratio
        if employee_data.get('RemoteRatio', 50) < 20:
            custom['workplace'].insert(0, "🏠 Negotiate flexible or remote work options")
        
        return custom
    
    def generate_summary_report(self,
                               employee_data: Dict,
                               burnout_probability: float) -> str:
        """
        Generate a summary wellness report
        """
        
        if burnout_probability >= 0.7:
            risk_level = "Tinggi (High)"
            emoji = "🔴"
        elif burnout_probability >= 0.4:
            risk_level = "Sedang (Medium)"
            emoji = "🟡"
        else:
            risk_level = "Rendah (Low)"
            emoji = "🟢"
        
        report = f"""
╔════════════════════════════════════════════════════════════════╗
║         🔥 BURNOUT RISK WELLNESS REPORT                        ║
╚════════════════════════════════════════════════════════════════╝

Risk Level: {emoji} {risk_level}
Burnout Probability: {burnout_probability:.1%}

EMPLOYEE PROFILE:
  • Age: {employee_data.get('Age', 'N/A')}
  • Role: {employee_data.get('JobRole', 'N/A')}
  • Experience: {employee_data.get('Experience', 'N/A')} years
  • Weekly Hours: {employee_data.get('WorkHoursPerWeek', 'N/A')} hours
  • Remote: {employee_data.get('RemoteRatio', 'N/A')}%
  • Satisfaction: {employee_data.get('SatisfactionLevel', 'N/A')}/5
  • Stress: {employee_data.get('StressLevel', 'N/A')}/10

KEY INSIGHTS:
"""
        
        # Add insights based on profile
        if employee_data.get('WorkHoursPerWeek', 40) > 50:
            report += "  ⚠️ Work hours exceed recommended limits\n"
        
        if employee_data.get('StressLevel', 5) >= 7:
            report += "  ⚠️ High stress levels detected\n"
        
        if employee_data.get('SatisfactionLevel', 3) < 2.5:
            report += "  ⚠️ Low job satisfaction\n"
        
        if employee_data.get('RemoteRatio', 50) < 20:
            report += "  ⚠️ Limited work flexibility\n"
        
        report += """
NEXT STEPS:
  1. Review personalized recommendations below
  2. Discuss with HR or manager
  3. Implement short-term actions immediately
  4. Track progress with success metrics
  5. Schedule follow-up assessment in 4-8 weeks

═════════════════════════════════════════════════════════════════
        """
        
        return report


# ──────────────────────────────────────────────────────────────────────────────
# EXAMPLE USAGE
# ──────────────────────────────────────────────────────────────────────────────

def example_usage():
    """Demonstrate AI recommendation generation"""
    
    print("\n" + "="*70)
    print("EXAMPLE: AI RECOMMENDATION GENERATION")
    print("="*70)
    
    # Initialize engine
    engine = AIRecommendationEngine(use_gemini=GEMINI_AVAILABLE and bool(GEMINI_API_KEY))
    
    # Example employees
    examples = [
        {
            "data": {
                "Age": 32,
                "Gender": "Female",
                "JobRole": "Engineer",
                "Experience": 6,
                "WorkHoursPerWeek": 55,
                "RemoteRatio": 10,
                "SatisfactionLevel": 2.1,
                "StressLevel": 9,
            },
            "probability": 0.82,
            "name": "Employee: High Risk"
        },
        {
            "data": {
                "Age": 38,
                "Gender": "Male",
                "JobRole": "Manager",
                "Experience": 12,
                "WorkHoursPerWeek": 48,
                "RemoteRatio": 40,
                "SatisfactionLevel": 3.5,
                "StressLevel": 6,
            },
            "probability": 0.55,
            "name": "Employee: Medium Risk"
        }
    ]
    
    for example in examples:
        print(f"\n{example['name']}")
        print("─" * 70)
        
        # Generate summary
        summary = engine.generate_summary_report(example['data'], example['probability'])
        print(summary)
        
        # Generate recommendations
        recs = engine.generate_recommendations(example['data'], example['probability'])
        print("\nAI RECOMMENDATIONS:")
        print(json.dumps(recs, indent=2, ensure_ascii=False))


# ──────────────────────────────────────────────────────────────────────────────
# SETUP INSTRUCTIONS
# ──────────────────────────────────────────────────────────────────────────────

GEMINI_SETUP_INSTRUCTIONS = """
╔═══════════════════════════════════════════════════════════════════╗
║  SETTING UP GEMINI API FOR GENERATIVE AI RECOMMENDATIONS         ║
╚═══════════════════════════════════════════════════════════════════╝

Step 1: Get Gemini API Key
  1. Go to: https://makersuite.google.com/app/apikey
  2. Click "Create API Key"
  3. Copy your API key

Step 2: Install Google Generative AI
  $ pip install google-generativeai

Step 3: Set API Key (Choose one method)

  Method A: Environment Variable
    $ export GEMINI_API_KEY="your-api-key-here"
    
  Method B: Configuration File
    Create config.json in project root:
    {
        "GEMINI_API_KEY": "your-api-key-here"
    }
    
  Method C: In Code
    import generativeai as genai
    genai.configure(api_key="your-api-key-here")

Step 4: Verify Setup
  $ python generative_ai_recommendations.py

═══════════════════════════════════════════════════════════════════

Features:
  ✨ Personalized wellness recommendations
  📊 AI-generated action plans
  🎯 Risk assessment insights
  💡 Resource suggestions
  📈 Success metrics tracking
"""


# ──────────────────────────────────────────────────────────────────────────────
# MAIN
# ──────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    
    print(GEMINI_SETUP_INSTRUCTIONS)
    
    try:
        example_usage()
    except Exception as e:
        print(f"\n❌ Error running examples: {e}")
        print("\nMake sure to:")
        print("  1. Set GEMINI_API_KEY environment variable")
        print("  2. pip install google-generativeai")
        print("  3. Or use mock implementation (no API key needed)")
