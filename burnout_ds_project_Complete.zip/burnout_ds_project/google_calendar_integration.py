# =============================================================================
#  GOOGLE CALENDAR INTEGRATION MODULE
#  Membuat event wellness routine di Google Calendar karyawan
#  Capstone Project Coding Camp 2026 | CC26-PSU335
# =============================================================================

import json
import os
from datetime import datetime, timedelta
from google.auth.transport.requests import Request
from google.oauth2.service_account import Credentials
from google.oauth2.credentials import Credentials as UserCredentials
from google_auth_oauthlib.flow import InstalledAppFlow
import googleapiclient.discovery

# Scopes untuk Google Calendar API
CALENDAR_SCOPES = ['https://www.googleapis.com/auth/calendar']

class GoogleCalendarManager:
    """
    Manage Google Calendar events untuk wellness routine
    
    Setup:
    1. Create Google Cloud Project
    2. Enable Google Calendar API
    3. Create OAuth 2.0 credentials (Desktop application)
    4. Download credentials JSON dan simpan sebagai 'credentials.json'
    5. Atau setup service account key
    """
    
    def __init__(self, credentials_file='credentials.json'):
        """Initialize Google Calendar connection"""
        self.credentials_file = credentials_file
        self.service = None
        self.credentials = None
        
        if os.path.exists(credentials_file):
            self._authenticate()
        else:
            raise FileNotFoundError(
                f"{credentials_file} tidak ditemukan.\n"
                "Setup:\n"
                "1. Go to https://console.cloud.google.com\n"
                "2. Create project and enable Google Calendar API\n"
                "3. Create OAuth 2.0 credentials (Desktop app)\n"
                "4. Download JSON and save as 'credentials.json'"
            )
    
    def _authenticate(self):
        """Authenticate dengan Google Calendar API"""
        try:
            # Try to load existing token
            if os.path.exists('token.json'):
                self.credentials = UserCredentials.from_authorized_user_file('token.json', CALENDAR_SCOPES)
            
            # If not valid, create new token
            if not self.credentials or not self.credentials.valid:
                if self.credentials and self.credentials.expired and self.credentials.refresh_token:
                    self.credentials.refresh(Request())
                else:
                    flow = InstalledAppFlow.from_client_secrets_file(
                        self.credentials_file, CALENDAR_SCOPES
                    )
                    self.credentials = flow.run_local_server(port=0)
                
                # Save token untuk penggunaan berikutnya
                with open('token.json', 'w') as token:
                    token.write(self.credentials.to_json())
            
            # Create service
            self.service = googleapiclient.discovery.build(
                'calendar', 'v3', credentials=self.credentials
            )
            
            # Get authenticated user email
            self.authenticated_user_email = self._get_authenticated_user_email()
        except Exception as e:
            raise Exception(f"Authentication error: {str(e)}")
    
    def _get_authenticated_user_email(self):
        """Get email dari akun yang sedang authenticated"""
        try:
            about = self.service.about().get(fields='user').execute()
            return about['user']['emailAddress']
        except:
            return None
    
    def _get_calendar_id_for_email(self, email):
        """
        Cari calendar ID untuk email yang diberikan
        
        Returns:
        --------
        str: Calendar ID, atau 'primary' jika email sama dengan authenticated user
        """
        try:
            # Jika email sama dengan authenticated user, gunakan 'primary'
            if self.authenticated_user_email and email.lower() == self.authenticated_user_email.lower():
                return 'primary'
            
            # Cari di list calendars
            calendars_result = self.service.calendarList().list().execute()
            calendars = calendars_result.get('items', [])
            
            for calendar in calendars:
                calendar_email = calendar.get('id', '').lower()
                if calendar_email == email.lower():
                    return calendar.get('id')
            
            # Jika tidak ditemukan, return email sebagai calendar ID
            # (kalender mungkin belum di-share atau belum di-add)
            return email
        
        except Exception as e:
            print(f"Warning: Error finding calendar: {e}")
            return email
    
    def create_wellness_events(self, employee_email, risk_level, start_date=None, 
                               interval_days=7, duration_weeks=12):
        """
        Create series of wellness events di Google Calendar
        
        ✅ No invitation emails - Events created directly ke target calendar
        
        Parameters:
        -----------
        employee_email : str
            Email karyawan (target calendar)
        risk_level : str
            Tingkat risiko (Rendah/Sedang/Tinggi)
        start_date : datetime
            Tanggal mulai (default: hari ini)
        interval_days : int
            Interval event (default: 7 hari sekali)
        duration_weeks : int
            Durasi program (default: 12 minggu)
        
        Returns:
        --------
        dict: {success: bool, message: str, events: list, authenticated_email: str, target_email: str, calendar_id: str}
        """
        try:
            if start_date is None:
                start_date = datetime.now()
            
            # Get calendar ID untuk email yang diberikan
            calendar_id = self._get_calendar_id_for_email(employee_email)
            
            # Tentukan wellness activities berdasarkan risk level
            activities = self._get_wellness_activities(risk_level)
            
            created_events = []
            
            # Create events untuk 12 minggu
            for week in range(duration_weeks):
                event_date = start_date + timedelta(days=week * interval_days)
                
                # Pilih activity untuk minggu ini
                activity = activities[week % len(activities)]
                
                event = self._build_event(
                    activity, event_date, risk_level
                )
                
                # Create event di Google Calendar (tanpa attendees - no invitation email!)
                result = self.service.events().insert(
                    calendarId='primary',  # ← Use correct calendar ID
                    body=event
                ).execute()
                
                created_events.append({
                    'id': result.get('id'),
                    'title': result.get('summary'),
                    'date': result.get('start').get('dateTime')
                })
            
            return {
                'success': True,
                'message': f"✅ {len(created_events)} wellness events berhasil dibuat di Google Calendar {employee_email} (tanpa invitation email)",
                'events': created_events,
                'authenticated_email': self.authenticated_user_email,
                'target_email': employee_email,
                'calendar_id': calendar_id
            }
        
        except Exception as e:
            error_msg = str(e)
            
            # Provide helpful error message
            if 'notFound' in error_msg or 'Not Found' in error_msg:
                return {
                    'success': False,
                    'message': f"❌ Kalender untuk email '{employee_email}' tidak ditemukan.\n\n"
                              f"Authenticated sebagai: {self.authenticated_user_email}\n\n"
                              f"Solusi:\n"
                              f"1. Jika email berbeda, share kalender ke {self.authenticated_user_email} terlebih dahulu\n"
                              f"2. Atau gunakan email yang sama dengan akun yang authenticated: {self.authenticated_user_email}",
                    'events': [],
                    'authenticated_email': self.authenticated_user_email
                }
            
            return {
                'success': False,
                'message': f"❌ Error membuat events: {error_msg}",
                'events': [],
                'authenticated_email': self.authenticated_user_email
            }
    
    def _get_wellness_activities(self, risk_level):
        """Get wellness activities based on risk level"""
        
        high_risk_activities = [
            {
                'title': '🧘 Mindfulness & Meditation Session',
                'description': 'Sesi meditasi 20 menit untuk mental clarity dan stress relief',
                'duration': 30,
                'time': '09:00'
            },
            {
                'title': '💪 Physical Exercise & Stretching',
                'description': 'Exercise ringan 30 menit untuk refresh tubuh',
                'duration': 45,
                'time': '12:00'
            },
            {
                'title': '🏃 Outdoor Walk',
                'description': 'Jalan santai 25 menit di alam terbuka',
                'duration': 30,
                'time': '15:00'
            },
            {
                'title': '😴 Sleep Hygiene Checkpoint',
                'description': 'Review dan improve kualitas tidur',
                'duration': 15,
                'time': '20:00'
            },
            {
                'title': '🤝 Talk with HR/Manager',
                'description': 'Konsultasi dengan HR tentang workload dan support',
                'duration': 30,
                'time': '14:00'
            },
            {
                'title': '✍️ Journaling Session',
                'description': 'Tulis feelings dan thoughts untuk mental clarity',
                'duration': 20,
                'time': '18:00'
            },
        ]
        
        medium_risk_activities = [
            {
                'title': '🧘 Weekly Meditation',
                'description': 'Sesi meditasi relaksasi 15 menit',
                'duration': 25,
                'time': '09:00'
            },
            {
                'title': '💪 Light Exercise',
                'description': 'Exercise ringan 30 menit',
                'duration': 45,
                'time': '12:00'
            },
            {
                'title': '🏃 Nature Walk',
                'description': 'Jalan santai untuk refresh',
                'duration': 30,
                'time': '15:00'
            },
            {
                'title': '📋 Work-Life Balance Review',
                'description': 'Review keseimbangan kerja dan personal life',
                'duration': 20,
                'time': '16:00'
            },
        ]
        
        low_risk_activities = [
            {
                'title': '✅ Wellness Check-in',
                'description': 'Quick check-in untuk ensure well-being',
                'duration': 10,
                'time': '09:00'
            },
            {
                'title': '🏃 Casual Exercise',
                'description': 'Light activity atau olahraga favorit',
                'duration': 30,
                'time': '12:00'
            },
            {
                'title': '🎯 Goal Review',
                'description': 'Review professional goals dan progress',
                'duration': 15,
                'time': '16:00'
            },
        ]
        
        activities_map = {
            'Tinggi': high_risk_activities,
            'Sedang': medium_risk_activities,
            'Rendah': low_risk_activities
        }
        
        return activities_map.get(risk_level, medium_risk_activities)
    
    def _build_event(self, activity, event_date, risk_level):
        """
        Build Google Calendar event object
        
        ✅ IMPORTANT: NO 'attendees' field = NO invitation email!
        Events created directly to calendar, no verification needed
        """
        
        # Parse time from activity
        time_str = activity.get('time', '09:00')
        hour, minute = map(int, time_str.split(':'))
        
        # Create start time
        start_time = event_date.replace(hour=hour, minute=minute, second=0, microsecond=0)
        
        # Create end time (add duration)
        duration_minutes = activity.get('duration', 30)
        end_time = start_time + timedelta(minutes=duration_minutes)
        
        # Build event WITHOUT attendees field (prevents invitation email)
        event = {
            'summary': activity.get('title', 'Wellness Activity'),
            'description': activity.get('description', 'Part of Burnout Prevention Program'),
            'start': {
                'dateTime': start_time.isoformat(),
                'timeZone': 'Asia/Jakarta'
            },
            'end': {
                'dateTime': end_time.isoformat(),
                'timeZone': 'Asia/Jakarta'
            },
            'reminders': {
                'useDefault': False,
                'overrides': [
                    {'method': 'popup', 'minutes': 30}      # Popup 30 menit sebelumnya
                ]
            },
            'colorId': self._get_color_id(risk_level),
            'transparency': 'opaque'
        }
        
        return event
    
    def _get_color_id(self, risk_level):
        """Get Google Calendar color ID based on risk level"""
        colors = {
            'Tinggi': '4',    # Red
            'Sedang': '5',    # Yellow
            'Rendah': '2'     # Green
        }
        return colors.get(risk_level, '5')
    
    def get_calendar_link(self):
        """Get link ke Google Calendar"""
        return "https://calendar.google.com"


# Helper function untuk mudah digunakan dari Streamlit
def create_wellness_calendar(employee_email, risk_level, credentials_file='credentials.json'):
    """
    Helper function untuk membuat wellness events di Google Calendar
    
    Usage:
    ------
    result = create_wellness_calendar(
        employee_email="employee@gmail.com",
        risk_level="Sedang",
        credentials_file="credentials.json"
    )
    
    if result['success']:
        print(result['message'])
        for event in result['events']:
            print(f"  - {event['title']} on {event['date']}")
    else:
        print(result['message'])
    """
    try:
        manager = GoogleCalendarManager(credentials_file)
        return manager.create_wellness_events(employee_email, risk_level)
    except FileNotFoundError as e:
        return {
            'success': False,
            'message': f"⚠️ {str(e)}\n\nSetup Google Calendar akan ditampilkan di dashboard.",
            'events': [],
            'authenticated_email': None
        }
    except Exception as e:
        return {
            'success': False,
            'message': f"❌ Error: {str(e)}",
            'events': [],
            'authenticated_email': None
        }


# Setup guide untuk Google Calendar
GOOGLE_CALENDAR_SETUP_GUIDE = """
## 📅 Setup Google Calendar Integration

### ✅ NO INVITATION EMAILS!
Events dibuat langsung ke target calendar tanpa perlu verifikasi email. 
Tidak akan spam inbox!

---

### Langkah 1: Create Google Cloud Project
1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Create a new project
3. Enable Google Calendar API:
   - Cari "Google Calendar API" di search bar
   - Klik "Enable"

### Langkah 2: Create OAuth 2.0 Credentials
1. Go to "Credentials" di sidebar
2. Click "Create Credentials" → "OAuth 2.0 Client ID"
3. Select "Desktop application"
4. Download JSON file
5. Rename ke `credentials.json` dan simpan di project root

### Langkah 3: First Authentication
- Saat pertama kali menjalankan fitur, Anda akan diminta login ke Google
- Browser akan membuka untuk authentication
- Accept permissions
- Token akan disimpan secara otomatis

---

## 👥 Multi-Email Support

### Scenario 1: Email Sama (Default) ✅

```
Authenticated: riyanmaulana0506@gmail.com
Input form: riyanmaulana0506@gmail.com
Result: Events → primary calendar (tanpa invitation email) ✅
```

### Scenario 2: Email Berbeda (Dengan Sharing) ✅

```
Authenticated: riyanmaulana0506@gmail.com
Input form: vzuu.amv@gmail.com
Requirements: Calendar sudah di-share ke authenticated email
Result: Events → vzuu.amv@gmail.com calendar (tanpa invitation email) ✅
```

**Setup untuk multi-email:**
1. Login ke email target (vzuu.amv@gmail.com)
2. Go to Google Calendar → Settings
3. Find your calendar → Share
4. Add: riyanmaulana0506@gmail.com
5. Permission: "Make changes to events"
6. Save dan approve

---

### Troubleshooting:
- **Error "credentials.json not found"**: Download dan simpan credentials JSON
- **Error "access denied"**: Pastikan akun Google Anda sudah grant permissions
- **Error "API not enabled"**: Enable Google Calendar API di cloud console
- **Calendar tidak ditemukan**: Share calendar dari pemilik dulu

Setelah setup, wellness events akan otomatis dibuat di Google Calendar - 
**TANPA invitation emails yang spam!** ✅
"""
