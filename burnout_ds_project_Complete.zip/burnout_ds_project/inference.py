# =============================================================================
#  BURNOUT RISK PREDICTION SYSTEM — INFERENCE SCRIPT
#  Make predictions on new employee data
#  Capstone Project Coding Camp 2026 | CC26-PSU335
# =============================================================================

import os
import pickle
import numpy as np
import pandas as pd
import tensorflow as tf
import warnings
warnings.filterwarnings("ignore")

from sklearn.preprocessing import LabelEncoder

# ── Konfigurasi Path ──────────────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(BASE_DIR, "models")
EXPORTS_DIR = os.path.join(BASE_DIR, "exported_models")

print("="*70)
print("BURNOUT RISK PREDICTION INFERENCE ENGINE")
print("="*70)


class BurnoutPredictor:
    """
    Burnout Risk Prediction Inference Engine
    
    Handles:
    - Model loading (Keras, SavedModel)
    - Feature preprocessing
    - Prediction generation
    - Risk level classification
    - Result formatting
    """
    
    def __init__(self, model_path=None, artifacts_path=None):
        """
        Initialize predictor
        
        Args:
            model_path (str): Path to .keras or SavedModel directory
            artifacts_path (str): Path to artifacts pickle file
        """
        self.model = None
        self.scaler = None
        self.features = None
        self.le_gender = None
        self.le_role = None
        
        if artifacts_path is None:
            artifacts_path = os.path.join(MODEL_DIR, "dl_artifacts.pkl")
        
        if model_path is None:
            # Try to find .keras file first
            keras_file = os.path.join(EXPORTS_DIR, "burnout_model.keras")
            if os.path.exists(keras_file):
                model_path = keras_file
            else:
                model_path = os.path.join(MODEL_DIR, "burnout_model.h5")
        
        self.load_artifacts(artifacts_path)
        self.load_model(model_path)
    
    def load_artifacts(self, artifacts_path):
        """Load preprocessing artifacts"""
        print(f"\n── LOADING ARTIFACTS ──")
        print(f"   Path: {artifacts_path}")
        
        try:
            with open(artifacts_path, "rb") as f:
                artifacts = pickle.load(f)
            
            self.scaler = artifacts["scaler"]
            self.features = artifacts["features"]
            
            print(f"   ✅ Artifacts loaded successfully!")
            print(f"   Features: {len(self.features)}")
            
        except Exception as e:
            print(f"   ❌ Error loading artifacts: {e}")
            raise
    
    def load_model(self, model_path):
        """Load trained model"""
        print(f"\n── LOADING MODEL ──")
        print(f"   Path: {model_path}")
        
        try:
            # Check if path exists
            if not os.path.exists(model_path):
                print(f"   ⚠️ Model not found at {model_path}")
                print(f"   Trying to find alternative model paths...")
                
                # Try alternatives
                alternatives = [
                    os.path.join(MODEL_DIR, "burnout_model.h5"),
                    os.path.join(EXPORTS_DIR, "burnout_model.keras"),
                    os.path.join(EXPORTS_DIR, "burnout_model_savedmodel"),
                ]
                
                for alt_path in alternatives:
                    if os.path.exists(alt_path):
                        model_path = alt_path
                        print(f"   Found alternative: {model_path}")
                        break
            
            self.model = tf.keras.models.load_model(model_path)
            print(f"   ✅ Model loaded successfully!")
            print(f"   Parameters: {self.model.count_params():,}")
            
        except Exception as e:
            print(f"   ❌ Error loading model: {e}")
            raise
    
    def classify_risk_level(self, probability):
        """Classify risk level based on probability"""
        if probability >= 0.7:
            return "Tinggi (High)", "🔴"
        elif probability >= 0.4:
            return "Sedang (Medium)", "🟡"
        else:
            return "Rendah (Low)", "🟢"
    
    def prepare_features(self, employee_data):
        """
        Prepare features from raw employee data
        
        Args:
            employee_data (dict): Raw employee features
        
        Returns:
            np.ndarray: Scaled feature vector
        """
        
        # Create DataFrame with required features
        df = pd.DataFrame([employee_data])
        
        # Encode categorical variables
        if "Gender" in df.columns:
            self.le_gender = self.le_gender or LabelEncoder()
            df["Gender_enc"] = self.le_gender.fit_transform(df["Gender"])
        else:
            df["Gender_enc"] = 1
        
        if "JobRole" in df.columns:
            self.le_role = self.le_role or LabelEncoder()
            df["JobRole_enc"] = self.le_role.fit_transform(df["JobRole"])
        else:
            df["JobRole_enc"] = 0
        
        # Engineer features
        df["StressWorkRatio"] = df["StressLevel"] / (df["WorkHoursPerWeek"] + 1)
        df["WorkLifeScore"] = df["SatisfactionLevel"] * (1 - df["RemoteRatio"] / 100)
        df["HighRiskFlag"] = (
            (df["StressLevel"] >= 7) & (df["WorkHoursPerWeek"] >= 50)
        ).astype(int)
        df["SeniorEmployee"] = (df["Experience"] >= 10).astype(int)
        df["StressCategory"] = pd.cut(
            df["StressLevel"],
            bins=[0, 3, 6, 10],
            labels=[0, 1, 2]
        ).astype(int)
        df["SatisfactionInverse"] = 5.0 - df["SatisfactionLevel"]
        
        # Extract features in correct order
        X = df[self.features].values
        
        # Scale
        X_scaled = self.scaler.transform(X)
        
        return X_scaled
    
    def predict(self, employee_data):
        """
        Make prediction for single employee
        
        Args:
            employee_data (dict): Employee features
        
        Returns:
            dict: Prediction results with confidence and risk level
        """
        
        # Prepare features
        X_scaled = self.prepare_features(employee_data)
        
        # Make prediction
        probability = self.model.predict(X_scaled, verbose=0)[0][0]
        burnout_class = int(probability > 0.5)
        risk_level, risk_emoji = self.classify_risk_level(probability)
        
        return {
            "burnout_probability": float(probability),
            "burnout_class": burnout_class,
            "risk_level": risk_level,
            "risk_emoji": risk_emoji,
            "confidence": float(max(probability, 1 - probability)),
        }
    
    def predict_batch(self, employees_data):
        """
        Make predictions for multiple employees
        
        Args:
            employees_data (list/pd.DataFrame): Multiple employee records
        
        Returns:
            pd.DataFrame: Predictions for all employees
        """
        
        results = []
        
        if isinstance(employees_data, pd.DataFrame):
            employees_list = employees_data.to_dict("records")
        else:
            employees_list = employees_data
        
        print(f"\n  Processing {len(employees_list)} employees...")
        
        for i, emp_data in enumerate(employees_list):
            prediction = self.predict(emp_data)
            prediction.update(emp_data)  # Add input features
            results.append(prediction)
            
            if (i + 1) % 100 == 0 or i == len(employees_list) - 1:
                print(f"    ✓ Processed {i+1}/{len(employees_list)}")
        
        return pd.DataFrame(results)
    
    def format_result(self, prediction_result):
        """Format prediction result for display"""
        result_str = f"""
{'='*60}
BURNOUT RISK ASSESSMENT
{'='*60}

Risk Level: {prediction_result['risk_emoji']} {prediction_result['risk_level']}
Burnout Probability: {prediction_result['burnout_probability']:.1%}
Confidence: {prediction_result['confidence']:.1%}
{'='*60}
        """
        return result_str


# =============================================================================
# EXAMPLE PREDICTIONS
# =============================================================================

def example_predictions():
    """Run example predictions"""
    
    print("\n" + "="*70)
    print("EXAMPLE PREDICTIONS")
    print("="*70)
    
    # Initialize predictor
    predictor = BurnoutPredictor()
    
    # Example 1: Low risk employee
    print("\n── EXAMPLE 1: Low Risk Employee ──")
    emp_low_risk = {
        "Age": 32,
        "Gender": "Female",
        "JobRole": "Analyst",
        "Experience": 5,
        "WorkHoursPerWeek": 38,
        "RemoteRatio": 60,
        "SatisfactionLevel": 4.2,
        "StressLevel": 3,
    }
    
    result_low = predictor.predict(emp_low_risk)
    print(predictor.format_result(result_low))
    
    # Example 2: Medium risk employee
    print("\n── EXAMPLE 2: Medium Risk Employee ──")
    emp_med_risk = {
        "Age": 42,
        "Gender": "Male",
        "JobRole": "Manager",
        "Experience": 12,
        "WorkHoursPerWeek": 48,
        "RemoteRatio": 20,
        "SatisfactionLevel": 2.8,
        "StressLevel": 6,
    }
    
    result_med = predictor.predict(emp_med_risk)
    print(predictor.format_result(result_med))
    
    # Example 3: High risk employee
    print("\n── EXAMPLE 3: High Risk Employee ──")
    emp_high_risk = {
        "Age": 38,
        "Gender": "Female",
        "JobRole": "Engineer",
        "Experience": 8,
        "WorkHoursPerWeek": 55,
        "RemoteRatio": 10,
        "SatisfactionLevel": 1.9,
        "StressLevel": 9,
    }
    
    result_high = predictor.predict(emp_high_risk)
    print(predictor.format_result(result_high))
    
    # Batch prediction
    print("\n── BATCH PREDICTION ──")
    batch_data = [emp_low_risk, emp_med_risk, emp_high_risk]
    batch_results = predictor.predict_batch(batch_data)
    
    print("\nBatch Results Summary:")
    print(batch_results[["Age", "JobRole", "Experience", "StressLevel", 
                        "burnout_probability", "risk_level"]].to_string(index=False))
    
    return predictor


def predict_from_csv(csv_path):
    """Make predictions for all employees in CSV file"""
    
    print(f"\n── BATCH PREDICTION FROM CSV ──")
    print(f"   Path: {csv_path}")
    
    try:
        # Load CSV
        df = pd.read_csv(csv_path)
        print(f"   ✅ CSV loaded: {len(df)} employees")
        
        # Initialize predictor
        predictor = BurnoutPredictor()
        
        # Make predictions
        predictions = predictor.predict_batch(df)
        
        # Save results
        output_path = csv_path.replace(".csv", "_predictions.csv")
        predictions.to_csv(output_path, index=False)
        print(f"   ✅ Predictions saved: {output_path}")
        
        # Statistics
        print(f"\n   Prediction Statistics:")
        print(f"     High Risk (≥0.7): {(predictions['burnout_probability'] >= 0.7).sum()}")
        print(f"     Medium Risk (0.4-0.7): {((predictions['burnout_probability'] >= 0.4) & (predictions['burnout_probability'] < 0.7)).sum()}")
        print(f"     Low Risk (<0.4): {(predictions['burnout_probability'] < 0.4).sum()}")
        
        return predictions
        
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return None


# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    
    print("\n" + "="*70)
    print("🔥 BURNOUT RISK PREDICTION — INFERENCE")
    print("="*70)
    
    # Run example predictions
    try:
        predictor = example_predictions()
        
        print("\n" + "="*70)
        print("✅ INFERENCE COMPLETED")
        print("="*70)
        
        print(f"\nUsage:")
        print(f"""
  # Single prediction
  predictor = BurnoutPredictor()
  result = predictor.predict({{"Age": 35, "Gender": "Male", ...}})
  
  # Batch prediction
  results_df = predictor.predict_batch(employees_list)
  
  # From CSV file
  from inference import predict_from_csv
  results = predict_from_csv("employees.csv")
        """)
        
    except Exception as e:
        print(f"\n❌ Error during inference: {e}")
        print(f"\nMake sure to run:")
        print(f"  1. python model_deep_learning.py")
        print(f"  2. python export_model.py")
