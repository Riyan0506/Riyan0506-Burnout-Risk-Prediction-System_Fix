# =============================================================================
#  BURNOUT RISK PREDICTION SYSTEM — DEEP LEARNING MODEL
#  TensorFlow Implementation with Custom Components
#  Capstone Project Coding Camp 2026 | CC26-PSU335
# =============================================================================

import os
import pickle
import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings("ignore")

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, losses, optimizers
from tensorflow.keras.callbacks import Callback, TensorBoard
from tensorflow.keras.callbacks import (
    Callback,
    TensorBoard,
    EarlyStopping,
    ReduceLROnPlateau,
    ModelCheckpoint
)

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import (
    accuracy_score, f1_score, precision_score, recall_score,
    roc_auc_score, classification_report, confusion_matrix
)

# ── Konfigurasi Path ──────────────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(BASE_DIR, "synthetic_employee_burnout.csv")
MODEL_DIR = os.path.join(BASE_DIR, "models")
LOG_DIR = os.path.join(BASE_DIR, "logs")
os.makedirs(MODEL_DIR, exist_ok=True)
os.makedirs(LOG_DIR, exist_ok=True)

# ── TensorFlow Configuration ──────────────────────────────────────────────────
tf.random.set_seed(42)
np.random.seed(42)

print(f"TensorFlow Version: {tf.__version__}")
print(f"GPU Available: {tf.config.list_physical_devices('GPU')}")


# =============================================================================
# CUSTOM COMPONENTS
# =============================================================================

@tf.keras.utils.register_keras_serializable(package="Custom")
class WeightedBinaryCrossentropy(losses.Loss):

    def __init__(
        self,
        pos_weight=2.0,
        neg_weight=1.0,
        name="weighted_bce",
        **kwargs
    ):
        super().__init__(name=name, **kwargs)
        self.pos_weight = pos_weight
        self.neg_weight = neg_weight

    def call(self, y_true, y_pred):
        y_pred = tf.clip_by_value(y_pred, 1e-7, 1 - 1e-7)

        loss = -(
            self.pos_weight * y_true * tf.math.log(y_pred)
            + self.neg_weight * (1 - y_true) * tf.math.log(1 - y_pred)
        )

        return tf.reduce_mean(loss)

    def get_config(self):
        config = super().get_config()
        config.update({
            "pos_weight": self.pos_weight,
            "neg_weight": self.neg_weight,
        })
        return config

class BestMetricCallback(Callback):
    """
    Custom Callback: Best Metric Tracking
    
    Menyimpan model terbaik berdasarkan metrik validation tertentu.
    Juga mencatat best metrics dan logs ke console selama training.
    
    Features:
    - Early stopping ketika tidak ada improvement
    - Learning rate reduction on plateau
    - Best model checkpointing
    - Logging best metrics per epoch
    """
    def __init__(self, 
                 monitor="val_auc",
                 mode="max",
                 patience=10,
                 save_path=None,
                 verbose=1):
        super().__init__()
        self.monitor = monitor
        self.mode = mode
        self.patience = patience
        self.save_path = save_path or os.path.join(MODEL_DIR, "best_model.h5")
        self.verbose = verbose
        self.wait_count = 0
        self.stopped_epoch = 0
        
        if mode == "max":
            self.best_value = -np.inf
            self.compare_fn = lambda x, y: x > y
        else:
            self.best_value = np.inf
            self.compare_fn = lambda x, y: x < y
        
        self.best_epoch = 0
        self.best_metrics = {}
    
    def on_epoch_end(self, epoch, logs=None):
        logs = logs or {}
        current = logs.get(self.monitor)
        
        if current is None:
            return
        
        if self.compare_fn(current, self.best_value):
            self.best_value = current
            self.wait_count = 0
            self.best_epoch = epoch
            self.best_metrics = {k: v for k, v in logs.items()}
            
            # Save best model
            if self.save_path:
                self.model.save(self.save_path)
                if self.verbose > 0:
                    print(f"\n✅ Best model saved at epoch {epoch+1} ({self.monitor}={current:.4f})")
        else:
            self.wait_count += 1
            if self.wait_count >= self.patience:
                self.stopped_epoch = epoch
                self.model.stop_training = True
                if self.verbose > 0:
                    print(f"\n⚠️  Early stopping at epoch {epoch+1} (no improvement for {self.patience} epochs)")
        
        if self.verbose > 0 and epoch % 5 == 0:
            print(f"   Epoch {epoch+1:3d}: {self.monitor}={current:.4f} " +
                  f"(best={self.best_value:.4f} @ epoch {self.best_epoch+1})")
    
    def on_train_end(self, logs=None):
        if self.stopped_epoch > 0 and self.verbose > 0:
            print(f"\n🎯 Training stopped at epoch {self.stopped_epoch+1}")
            print(f"   Best epoch: {self.best_epoch+1} with metrics:")
            for k, v in self.best_metrics.items():
                print(f"     {k}: {v:.4f}")


class MetricsLoggingCallback(Callback):
    """
    Custom Callback: Metrics Logging
    
    Mencatat semua metrics per epoch (train, validation)
    untuk analisis training progression lebih detail.
    """
    def __init__(self, verbose=True):
        super().__init__()
        self.verbose = verbose
        self.history = {
            "epoch": [],
            "train_loss": [],
            "train_auc": [],
            "val_loss": [],
            "val_auc": [],
        }
    
    def on_epoch_end(self, epoch, logs=None):
        logs = logs or {}
        self.history["epoch"].append(epoch + 1)
        self.history["train_loss"].append(logs.get("loss", 0))
        self.history["train_auc"].append(logs.get("auc", 0))
        self.history["val_loss"].append(logs.get("val_loss", 0))
        self.history["val_auc"].append(logs.get("val_auc", 0))
    
    def get_history(self):
        return self.history


# =============================================================================
# FUNCTIONAL API MODEL ARCHITECTURE
# =============================================================================

def create_burnout_model(input_dim, use_dropout=True, dropout_rate=0.3):
    """
    Create TensorFlow Functional API Model
    
    Architecture:
    - Input Layer: input_dim features
    - Dense 128 + ReLU + Batch Norm + Dropout
    - Dense 64 + ReLU + Batch Norm + Dropout
    - Dense 32 + ReLU + Batch Norm + Dropout
    - Dense 16 + ReLU + Dropout
    - Output Dense 1 + Sigmoid (binary classification)
    
    Args:
        input_dim (int): Number of input features
        use_dropout (bool): Whether to use dropout regularization
        dropout_rate (float): Dropout rate
    
    Returns:
        tf.keras.Model: Compiled model ready for training
    """
    
    print("\n" + "="*70)
    print("BUILDING TensorFlow FUNCTIONAL API MODEL")
    print("="*70)
    
    # Input Layer
    inputs = keras.Input(shape=(input_dim,), name="input_features")
    
    # Hidden Layer 1: Dense(128)
    x = layers.Dense(128, name="dense_128")(inputs)
    x = layers.BatchNormalization(name="batch_norm_128")(x)
    x = layers.Activation("relu", name="relu_128")(x)
    if use_dropout:
        x = layers.Dropout(dropout_rate, name="dropout_128")(x)
    
    # Hidden Layer 2: Dense(64)
    x = layers.Dense(64, name="dense_64")(x)
    x = layers.BatchNormalization(name="batch_norm_64")(x)
    x = layers.Activation("relu", name="relu_64")(x)
    if use_dropout:
        x = layers.Dropout(dropout_rate, name="dropout_64")(x)
    
    # Hidden Layer 3: Dense(32)
    x = layers.Dense(32, name="dense_32")(x)
    x = layers.BatchNormalization(name="batch_norm_32")(x)
    x = layers.Activation("relu", name="relu_32")(x)
    if use_dropout:
        x = layers.Dropout(dropout_rate, name="dropout_32")(x)
    
    # Hidden Layer 4: Dense(16)
    x = layers.Dense(16, name="dense_16")(x)
    x = layers.Activation("relu", name="relu_16")(x)
    if use_dropout:
        x = layers.Dropout(dropout_rate / 2, name="dropout_16")(x)
    
    # Output Layer: Binary Classification
    outputs = layers.Dense(1, activation="sigmoid", name="output_burnout")(x)
    
    # Build Model
    model = keras.Model(inputs=inputs, outputs=outputs, name="BurnoutRiskPredictor")
    
    print(f"\n✅ Model Architecture Created:")
    print(f"   Input dimension: {input_dim}")
    print(f"   Use dropout: {use_dropout} (rate={dropout_rate})")
    
    # Compile Model with Custom Loss
    custom_loss = WeightedBinaryCrossentropy(pos_weight=2.5, neg_weight=1.0)
    model.compile(
        optimizer=optimizers.Adam(learning_rate=0.001),
        loss=custom_loss,
        metrics=[
            keras.metrics.AUC(name="auc"),
            keras.metrics.Precision(name="precision"),
            keras.metrics.Recall(name="recall"),
        ]
    )
    
    print(f"\n✅ Model Compiled with:")
    print(f"   Loss: Custom Weighted Binary Crossentropy")
    print(f"   Optimizer: Adam (lr=0.001)")
    print(f"   Metrics: AUC, Precision, Recall")
    
    return model


def get_model_summary(model):
    """Print detailed model summary"""
    print("\n" + "="*70)
    print("MODEL ARCHITECTURE SUMMARY")
    print("="*70)
    model.summary()


# =============================================================================
# DATA PREPARATION
# =============================================================================

def prepare_data():
    """Load and prepare data for deep learning training"""
    
    print("\n" + "="*70)
    print("PREPARING DATA")
    print("="*70)
    
    # Load raw data
    df = pd.read_csv(DATA_PATH)
    print(f"\n  Dataset loaded: {df.shape[0]} rows × {df.shape[1]} columns")
    
    # Basic cleaning (from original burnout_analysis.py)
    df_clean = df.copy()
    
    # Feature Engineering (samma as original)
    le_gender = LabelEncoder()
    le_role = LabelEncoder()
    df_model = df_clean.copy()
    df_model["Gender_enc"] = le_gender.fit_transform(df_model["Gender"])
    df_model["JobRole_enc"] = le_role.fit_transform(df_model["JobRole"])
    
    # Engineered features
    df_model["StressWorkRatio"] = df_model["StressLevel"] / (df_model["WorkHoursPerWeek"] + 1)
    df_model["WorkLifeScore"] = df_model["SatisfactionLevel"] * (1 - df_model["RemoteRatio"] / 100)
    df_model["HighRiskFlag"] = (
        (df_model["StressLevel"] >= 7) & (df_model["WorkHoursPerWeek"] >= 50)
    ).astype(int)
    df_model["SeniorEmployee"] = (df_model["Experience"] >= 10).astype(int)
    df_model["StressCategory"] = pd.cut(
        df_model["StressLevel"],
        bins=[0, 3, 6, 10],
        labels=[0, 1, 2]
    ).astype(int)
    df_model["SatisfactionInverse"] = 5.0 - df_model["SatisfactionLevel"]
    
    FEATURES = [
        "Age", "Experience", "WorkHoursPerWeek", "RemoteRatio",
        "SatisfactionLevel", "StressLevel",
        "Gender_enc", "JobRole_enc",
        "StressWorkRatio", "WorkLifeScore",
        "HighRiskFlag", "SeniorEmployee",
        "StressCategory", "SatisfactionInverse"
    ]
    
    X = df_model[FEATURES].values
    y = df_model["Burnout"].values
    
    print(f"\n  Features extracted: {len(FEATURES)}")
    print(f"  Target distribution:")
    print(f"    - No Burnout (0): {(y==0).sum():,} ({(y==0).mean()*100:.1f}%)")
    print(f"    - Burnout (1): {(y==1).sum():,} ({(y==1).mean()*100:.1f}%)")
    
    # Scaling
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # Train-Test Split (stratified)
    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=0.2, random_state=42, stratify=y
    )
    
    print(f"\n  Data Split (stratified 80/20):")
    print(f"    Train: {len(X_train):,} samples")
    print(f"    Test: {len(X_test):,} samples")
    
    return X_train, X_test, y_train, y_test, scaler, FEATURES


# =============================================================================
# TRAINING
# =============================================================================

def train_model(model, X_train, X_test, y_train, y_test, epochs=100, batch_size=32):
    """
    Train the Deep Learning Model
    
    Uses custom callbacks for monitoring and early stopping.
    """
    
    print("\n" + "="*70)
    print("TRAINING DEEP LEARNING MODEL")
    print("="*70)
    
    # Create callbacks
    tensorboard_cb = TensorBoard(
        log_dir=LOG_DIR,
        histogram_freq=1,
        write_graph=True,
        update_freq='epoch',
    )
    
    best_metric_cb = BestMetricCallback(
        monitor="val_auc",
        mode="max",
        patience=15,
        save_path=os.path.join(MODEL_DIR, "best_model.h5"),
        verbose=1
    )
    
    metrics_logging_cb = MetricsLoggingCallback(verbose=False)
    
    lr_reduction_cb = ReduceLROnPlateau(
        monitor="val_loss",
        factor=0.5,
        patience=5,
        min_lr=0.00001,
        verbose=1
    )
    
    print(f"\n  Training configuration:")
    print(f"    Epochs: {epochs}")
    print(f"    Batch size: {batch_size}")
    print(f"    Early stopping patience: 15 epochs")
    print(f"    LR reduction: factor=0.5, patience=5")
    print(f"    Logging directory: {LOG_DIR}")
    
    # Train
    print("\n  Starting training...\n")
    history = model.fit(
        X_train, y_train,
        validation_data=(X_test, y_test),
        epochs=epochs,
        batch_size=batch_size,
        callbacks=[
            tensorboard_cb,
            best_metric_cb,
            metrics_logging_cb,
            lr_reduction_cb,
        ],
        verbose=0,
    )
    
    print(f"\n✅ Training completed!")
    
    return model, history


# =============================================================================
# EVALUATION
# =============================================================================

def evaluate_model(model, X_test, y_test):
    """Evaluate model on test set"""
    
    print("\n" + "="*70)
    print("MODEL EVALUATION")
    print("="*70)
    
    # Predictions
    y_pred_prob = model.predict(X_test, verbose=0)
    y_pred = (y_pred_prob > 0.5).astype(int).flatten()
    
    # Metrics
    accuracy = accuracy_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    recall = recall_score(y_test, y_pred)
    auc = roc_auc_score(y_test, y_pred_prob)
    
    print(f"\n  Deep Learning Model Performance:")
    print(f"    Accuracy:  {accuracy:.4f} {'✅' if accuracy >= 0.85 else '⚠️'}")
    print(f"    F1-Score:  {f1:.4f}")
    print(f"    Precision: {precision:.4f}")
    print(f"    Recall:    {recall:.4f}")
    print(f"    AUC-ROC:   {auc:.4f} {'✅' if auc >= 0.85 else '⚠️'}")
    
    print(f"\n  Classification Report:")
    print(classification_report(y_test, y_pred, target_names=["No Burnout", "Burnout"]))
    
    print(f"\n  Confusion Matrix:")
    cm = confusion_matrix(y_test, y_pred)
    print(f"    [[TN={cm[0,0]}  FP={cm[0,1]}]")
    print(f"     [FN={cm[1,0]}  TP={cm[1,1]}]]")
    
    metrics = {
        "Accuracy": accuracy,
        "F1": f1,
        "Precision": precision,
        "Recall": recall,
        "AUC-ROC": auc,
    }
    
    return metrics, y_pred, y_pred_prob


# =============================================================================
# MAIN EXECUTION
# =============================================================================

if __name__ == "__main__":
    
    print("\n" + "="*70)
    print("🔥 BURNOUT RISK PREDICTION — DEEP LEARNING MODEL")
    print("="*70)
    
    # 1. Prepare data
    X_train, X_test, y_train, y_test, scaler, features = prepare_data()
    input_dim = X_train.shape[1]
    
    # 2. Create model
    model = create_burnout_model(input_dim=input_dim, use_dropout=True, dropout_rate=0.3)
    get_model_summary(model)
    
    # 3. Train model
    model, history = train_model(
        model, X_train, X_test, y_train, y_test,
        epochs=100,
        batch_size=32
    )
    
    # 4. Evaluate model
    metrics, y_pred, y_pred_prob = evaluate_model(model, X_test, y_test)
    
    # 5. Save artifacts
    print("\n" + "="*70)
    print("SAVING ARTIFACTS")
    print("="*70)
    
    # Save model (will be done via export_model.py)
    model.save(os.path.join(MODEL_DIR, "burnout_model.h5"))
    print(f"  ✓ Model saved: {os.path.join(MODEL_DIR, 'burnout_model.h5')}")
    
    # Save preprocessing artifacts
    dl_artifacts = {
        "scaler": scaler,
        "features": features,
        "metrics": metrics,
        "input_dim": input_dim,
    }
    
    with open(os.path.join(MODEL_DIR, "dl_artifacts.pkl"), "wb") as f:
        pickle.dump(dl_artifacts, f)
    print(f"  ✓ Artifacts saved: {os.path.join(MODEL_DIR, 'dl_artifacts.pkl')}")
    
    print("\n" + "="*70)
    print("✅ DEEP LEARNING MODEL TRAINING COMPLETED")
    print("="*70)
    print(f"\nNext steps:")
    print(f"  1. Export model: python export_model.py")
    print(f"  2. Make predictions: python inference.py")
    print(f"  3. Start API server: python api_server.py")
    print(f"  4. View TensorBoard: tensorboard --logdir={LOG_DIR}")
