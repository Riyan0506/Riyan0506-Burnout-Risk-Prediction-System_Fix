# 🔥 Burnout Risk Prediction System — Data Scientist Files
**Capstone Project Coding Camp 2026 | CC26-PSU335**
**Tema: Healthy Lives & Well-being**

---

## 📁 Struktur File

```
burnout_ds_project/
│
├── DATA & ANALISIS
├── burnout_analysis.py          ← Script Python utama (jalankan ini dulu!)
├── burnout_analysis.ipynb       ← Versi Jupyter Notebook (interaktif)
├── synthetic_employee_burnout.csv  ← Dataset mentah
├── df_clean.csv                 ← Dataset bersih (generated)
├── data_dictionary.csv          ← Kamus data (generated)
│
├── MODEL & ARTIFACTS
├── model_artifacts.pkl          ← Model ML + encoder + scaler (generated)
├── models/                      ← Deep learning models
│   ├── best_model.h5            ← Best Keras model
│   ├── burnout_model.h5         ← Keras model
│   └── dl_artifacts.pkl         ← DL preprocessing artifacts
├── exported_models/             ← Exported TensorFlow models
│   ├── burnout_model.keras      ← Keras format
│   ├── burnout_model_savedmodel/
│   └── model_metadata.json      ← Metadata
│
├── DASHBOARD & API
├── dashboard_burnout.py         ← Dashboard Streamlit
├── api_server.py                ← FastAPI server (inference endpoint)
├── inference.py                 ← Inference module
├── export_model.py              ← Model export utilities
│
├── INTEGRASI & NOTIFIKASI
├── email_notification.py       ← Email notification system
├── google_calendar_integration.py ← Google Calendar integration
├── generative_ai_recommendations.py ← AI-powered recommendations
│
├── DEEP LEARNING
├── model_deep_learning.py       ← Deep learning model training
│
├── KONFIGURASI
├── requirements.txt            ← Daftar library
├── .env                        ← Environment variables
├── credentials.json            ← Google API credentials
├── token.json                  ← Google Calendar token
│
├── VISUALISASI (generated)
├── fig1_distribusi_fitur.png
├── fig2_heatmap_korelasi.png
├── fig3_burnout_kategori.png
├── fig4_boxplot_burnout.png
├── fig5_risk_level.png
├── fig6_scatter_burnout.png
├── fig7_explanatory.png
└── fig8_ab_testing.png
```

---

## 🚀 Cara Menjalankan

### Step 1: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 2: Jalankan Pipeline Analisis
```bash
# Opsi A: Script Python langsung
python burnout_analysis.py

# Opsi B: Jupyter Notebook (lebih interaktif, ada penjelasan di setiap cell)
jupyter notebook burnout_analysis.ipynb
```

> ⚠️ Wajib jalankan Step 2 terlebih dahulu sebelum dashboard!
> Script ini menghasilkan `model_artifacts.pkl` dan `df_clean.csv` yang dibutuhkan dashboard.

### Step 3: Jalankan Dashboard Streamlit (Lokal)
```bash
streamlit run dashboard_burnout.py
```
Dashboard akan otomatis terbuka di browser: `http://localhost:8501`

---

## 🤖 Model Inference

### Opsi A: Via Python Script
```python
import pickle
import pandas as pd

# Load artifacts
with open("model_artifacts.pkl", "rb") as f:
    artifacts = pickle.load(f)

model     = artifacts["best_model"]
scaler    = artifacts["scaler"]
le_gender = artifacts["le_gender"]
le_role   = artifacts["le_role"]
FEATURES  = artifacts["features"]

# Contoh inference
def predict_burnout(age, gender, job_role, experience, work_hours,
                    remote, satisfaction, stress):
    gender_enc   = le_gender.transform([gender])[0]
    role_enc     = le_role.transform([job_role])[0]
    stress_ratio = stress / (work_hours + 1)
    wl_score     = satisfaction * (1 - remote / 100)
    high_risk    = int(stress >= 7 and work_hours >= 50)
    senior       = int(experience >= 10)
    stress_cat   = 0 if stress <= 3 else (1 if stress <= 6 else 2)
    sat_inv      = 5.0 - satisfaction

    X = pd.DataFrame([[age, experience, work_hours, remote, satisfaction, stress,
                       gender_enc, role_enc, stress_ratio, wl_score,
                       high_risk, senior, stress_cat, sat_inv]],
                     columns=FEATURES)
    X_scaled   = scaler.transform(X)
    prediction = model.predict(X_scaled)[0]
    proba      = model.predict_proba(X_scaled)[0][1]
    return {"burnout": int(prediction), "probability": float(proba)}
```

### Opsi B: Via FastAPI Server
```bash
python api_server.py
```
Akses endpoint: `http://localhost:8000/docs`

---

## ☁️ Deploy Dashboard ke Streamlit Cloud (Publik)

### Prasyarat
- Akun GitHub
- Akun Streamlit Cloud (gratis di [streamlit.io/cloud](https://streamlit.io/cloud))

### Langkah-langkah

**1. Persiapkan Repository GitHub**
```bash
git init
git add dashboard_burnout.py model_artifacts.pkl df_clean.csv requirements.txt
git commit -m "feat: burnout risk prediction dashboard"
git remote add origin https://github.com/USERNAME/burnout-prediction.git
git push -u origin main
```

**2. Deploy di Streamlit Cloud**
1. Buka [https://streamlit.io/cloud](https://streamlit.io/cloud)
2. Klik **"New app"**
3. Pilih repository GitHub yang sudah di-push
4. Set **Main file path**: `dashboard_burnout.py`
5. Klik **"Deploy!"**

**3. Dapatkan URL Publik**
```
https://USERNAME-burnout-prediction-dashboard-burnout-XXXXX.streamlit.app
```

---

## 📧 Integrasi Email & Calendar

### Setup Email Notification
1. Buat file `.env` dengan konfigurasi email:
   ```
   SENDER_EMAIL=your_email@gmail.com
   SENDER_PASSWORD=your_app_password
   SMTP_SERVER=smtp.gmail.com
   SMTP_PORT=587
   ```
2. Jalankan: `python email_notification.py`

### Setup Google Calendar Integration
1. Ikuti panduan di `EMAIL_CALENDAR_SETUP.md`
2. Buat `credentials.json` dari Google Cloud Console
3. Jalankan OAuth flow untuk generate `token.json`
4. Integrasikan ke dashboard untuk reminder otomatis

---

## 🧠 Deep Learning Model

Untuk model neural network:
```bash
python model_deep_learning.py
```

Model disimpan di:
- `models/burnout_model.h5`
- `models/best_model.h5`
- `exported_models/burnout_model.keras`

---

## 📊 Ringkasan Hasil Analisis

| Item | Hasil |
|------|-------|
| Total karyawan | 2.000 |
| Burnout rate | 6.5% |
| Faktor terkuat | StressLevel (r=+0.32), SatisfactionLevel (r=-0.23), WorkHoursPerWeek (r=+0.23) |
| Model terbaik | Gradient Boosting / Random Forest (AUC-ROC = 1.000) |
| A/B Test | Jam kerja ≥50 jam memiliki burnout rate 13.1% vs 0% untuk <40 jam (p<0.05 ✅) |

---

*Dibuat oleh tim Data Science CC26-PSU335 | Coding Camp 2026 × DBS Foundation*
